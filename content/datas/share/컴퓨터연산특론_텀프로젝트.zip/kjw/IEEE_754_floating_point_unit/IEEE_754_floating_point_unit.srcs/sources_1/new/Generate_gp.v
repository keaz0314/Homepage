`timescale 1ns / 1ps

module Generate_gp(
    input   wire    i_pre_g ,
    input   wire    i_pre_p ,
    input   wire    i_g     ,
    input   wire    i_p     ,
    output  wire    o_g     ,
    output  wire    o_p
);

assign  o_g = i_g | (i_p & i_pre_g) ;
assign  o_p = i_p & i_pre_p         ;

endmodule