`timescale 1ns / 1ps

module Significand_Normalizer(
    input   wire    [7  :   0]  i_exponent      ,
    input   wire    [24 :   0]  i_significand   ,
    output  wire    [7  :   0]  o_exponent      ,
    output  wire    [24 :   0]  o_significand   ,
    output  wire                o_underflow     ,
    output  wire                o_zero
);

reg     [7  :   0]  exponent    ;
reg     [24 :   0]  significand ;
reg     [4  :   0]  shift       ;
reg                 underflow   ;
reg                 zero        ;

always @(i_significand) begin
    casex(i_significand)
        25'b1_1xxx_xxxx_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand;
                                                    shift = 5'd0;
        end
        25'b1_01xx_xxxx_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 1;
                                                    shift = 5'd1;
        end
        25'b1_001x_xxxx_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 2;
                                                    shift = 5'd2;
        end
        25'b1_0001_xxxx_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 3;
                                                    shift = 5'd3;
        end
        25'b1_0000_1xxx_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 4;
                                                    shift = 5'd4;
        end
        25'b1_0000_01xx_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 5;
                                                    shift = 5'd5;
        end
        25'b1_0000_001x_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 6;
                                                    shift = 5'd6;
        end
        25'b1_0000_0001_xxxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 7;
                                                    shift = 5'd7;
        end
        25'b1_0000_0000_1xxx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 8;
                                                    shift = 5'd8;
        end
        25'b1_0000_0000_01xx_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 9;
                                                    shift = 5'd9;
        end
        25'b1_0000_0000_001x_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 10;
                                                    shift = 5'd10;
        end
        25'b1_0000_0000_0001_xxxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 11;
                                                    shift = 5'd11;
        end
        25'b1_0000_0000_0000_1xxx_xxxx_xxxx :   begin
                                                    significand = i_significand << 12;
                                                    shift = 5'd12;
        end
        25'b1_0000_0000_0000_01xx_xxxx_xxxx :   begin
                                                    significand = i_significand << 13;
                                                    shift = 5'd13;
        end
        25'b1_0000_0000_0000_001x_xxxx_xxxx :   begin
                                                    significand = i_significand << 14;
                                                    shift = 5'd14;
        end
        25'b1_0000_0000_0000_0001_xxxx_xxxx :   begin
                                                    significand = i_significand << 15;
                                                    shift = 5'd15;
        end
        25'b1_0000_0000_0000_0000_1xxx_xxxx :   begin
                                                    significand = i_significand << 16;
                                                    shift = 5'd16;
        end
        25'b1_0000_0000_0000_0000_01xx_xxxx :   begin
                                                    significand = i_significand << 17;
                                                    shift = 5'd17;
        end
        25'b1_0000_0000_0000_0000_001x_xxxx :   begin
                                                    significand = i_significand << 18;
                                                    shift = 5'd18;
        end
        25'b1_0000_0000_0000_0000_0001_xxxx :   begin
                                                    significand = i_significand << 19;
                                                    shift = 5'd19;
        end
        25'b1_0000_0000_0000_0000_0000_1xxx :   begin
                                                    significand = i_significand << 20;
                                                    shift = 5'd20;
        end
        25'b1_0000_0000_0000_0000_0000_01xx :   begin
                                                    significand = i_significand << 21;
                                                    shift = 5'd21;
        end
        25'b1_0000_0000_0000_0000_0000_001x :   begin
                                                    significand = i_significand << 22;
                                                    shift = 5'd22;
        end
        25'b1_0000_0000_0000_0000_0000_0001 :   begin
                                                    significand = i_significand << 23;
                                                    shift = 5'd23;
        end
        25'b1_0000_0000_0000_0000_0000_0000 :   begin
                                                    significand = i_significand << 24;
                                                    shift = 5'd24;
        end
        default :   begin
                        significand = 25'd0;
                        shift = 8'd0;
        end
    endcase
end

always @(*) begin
    if(i_exponent < shift) begin
        underflow = 1'b1;
        zero = 1'b0;
    end
    else if(i_exponent == shift) begin
        if(|significand[22:0]) begin
            underflow = 1'b1;
            zero = 1'b0;
        end
        else begin
            underflow = 1'b0;
            zero = 1'b1;
        end
    end
    else begin
        underflow = 1'b0;
        zero = 1'b0;
        exponent = i_exponent - shift;
    end
end
            
assign  o_exponent = exponent;
assign  o_significand = significand;
assign  o_underflow = underflow;
assign  o_zero = zero;

endmodule