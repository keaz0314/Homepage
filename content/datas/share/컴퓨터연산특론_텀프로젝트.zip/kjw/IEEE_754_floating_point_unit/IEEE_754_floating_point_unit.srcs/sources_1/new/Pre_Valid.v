`timescale 1ns / 1ps

module Pre_Valid(
    input   wire    [31 :   0]  i_operand_A,
    input   wire    [31 :   0]  i_operand_B,
    output  wire                o_exception
);

wire    infinity_NaN    ;
wire    denormalized_A  ;
wire    denormalized_B  ;

assign  infinity_NaN    = ((&i_operand_A[30:23]) == 1) || ((&i_operand_B[30:23]) == 1);
assign  denormalized_A  = ((|i_operand_A[30:23]) == 0) && ((|i_operand_A[22:0]) == 1);
assign  denormalized_B  = ((|i_operand_B[30:23]) == 0) && ((|i_operand_B[22:0]) == 1);

assign  o_exception = infinity_NaN | denormalized_A | denormalized_B;

endmodule
