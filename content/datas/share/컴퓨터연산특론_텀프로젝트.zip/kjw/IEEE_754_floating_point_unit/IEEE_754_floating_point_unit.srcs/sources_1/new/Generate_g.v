`timescale 1ns / 1ps

module Generate_g(
    input   wire    i_pre_g ,
    input   wire    i_g     ,
    input   wire    i_p     ,
    output  wire    o_g
);

assign  o_g = i_g | (i_p & i_pre_g);

endmodule