`timescale 1ns / 1ps

module Multiplication(
    input   wire                clk         ,
    input   wire                resetn      ,
    input   wire    [31 :   0]  i_operand_A ,
    input   wire    [31 :   0]  i_operand_B ,
    input   wire    [1  :   0]  i_operator  ,
    output  wire                o_exception ,
    output  wire    [31 :   0]  o_result
);

wire                sign                ;
wire                zero                ;
wire                overflow            ;
wire                underflow           ;
wire                round               ;

wire    [7  :   0]  exponent_A          ;
wire    [7  :   0]  exponent_B          ;
wire    [22 :   0]  fraction_A          ;
wire    [22 :   0]  fraction_B          ;
wire    [23 :   0]  significand_A       ;
wire    [23 :   0]  significand_B       ;
wire    [8  :   0]  mul_exponent        ;
wire    [47 :   0]  mul_significand     ;
wire    [8  :   0]  norm_exponent       ;
wire    [47 :   0]  norm_significand    ;
wire    [22 :   0]  final_fraction      ;


assign  exponent_A = i_operand_A[30:23];
assign  exponent_B = i_operand_B[30:23];
assign  fraction_A = i_operand_A[22:0];
assign  fraction_B = i_operand_B[22:0];

//부호 결정
assign  sign = i_operand_A[31] ^ i_operand_B[31];

//normalize, zero 판단
assign  significand_A = (|exponent_A) ? {1'b1, fraction_A} : {1'b0, fraction_A};
assign  significand_B = (|exponent_B) ? {1'b1, fraction_B} : {1'b0, fraction_B};

//normalize significand
//assign  mul_significand = significand_A * significand_B;
Carry_Save_Adder CSA(
    .clk        (clk            ),
    .resetn     (resetn         ),
    .i_A        (significand_A  ),
    .i_B        (significand_B  ),
    .o_result   (mul_significand)
);

assign  norm_significand = mul_significand[47] ? mul_significand : mul_significand << 1;

//round-to-nearest-even
//round bit = norm_significand[23]
//sticky bit = |norm_significand[22:0]
assign round = norm_significand[23] & (|norm_significand[22:0] | norm_significand[24]);
assign final_fraction = norm_significand[46:24] + round;
//always @(*) begin
//    if(norm_significand[23]) begin
//        if(|norm_significand[22:0]) begin
//            final_fraction = norm_significand[46:24] + 1'b1;
//        end
//        else begin
//            final_fraction = norm_significand[46:24] + norm_significand[24];
//        end
//    end
//    else begin
//        final_fraction = norm_significand[46:24];
//    end
//end

assign  mul_exponent = exponent_A + exponent_B - 8'd127;
assign  norm_exponent = mul_exponent + mul_significand[47];

assign  zero = (|exponent_A) == 1 && (|exponent_B) == 1 ? 1'b0 : 1'b1;

assign  overflow = (norm_exponent[8] & !norm_exponent[7]) | (&norm_exponent[7:0]);
assign  underflow = (norm_exponent[8] & norm_exponent[7]) | !(|norm_exponent[7:0]);
assign  o_exception = overflow | underflow;

assign  o_result = zero ? {sign, 31'b0} : {sign, norm_exponent[7:0], final_fraction};

endmodule