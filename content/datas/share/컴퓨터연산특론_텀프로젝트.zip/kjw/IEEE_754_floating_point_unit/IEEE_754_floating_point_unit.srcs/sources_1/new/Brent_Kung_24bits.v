`timescale 1ns / 1ps

module Brent_Kung_24bits(
    input   wire    [23 :   0]  i_A     ,
    input   wire    [23 :   0]  i_B     ,
    output  wire    [24 :   0]  o_result
);

wire    [23 :   0]  stage0_g    ;
wire    [23 :   0]  stage0_p    ;
wire    [10 :   0]  stage1_g    ;
wire    [10 :   0]  stage1_p    ;
wire    [4  :   0]  stage2_g    ;
wire    [4  :   0]  stage2_p    ;
wire    [1  :   0]  stage3_g    ;
wire    [1  :   0]  stage3_p    ;
wire    [23 :   0]  final_g     ;
wire    [22 :   0]  sum         ;

assign  stage0_g = i_A & i_B;
assign  stage0_p = i_A ^ i_B;

//stage 0 to 1
Generate_gp stage_1_gp0     (.i_pre_g   (stage0_g[2]    ), .i_pre_p (stage0_p[2]    ), .i_g (stage0_g[3]    ), .i_p (stage0_p[3]    ), .o_g (stage1_g[0]    ), .o_p (stage1_p[0]    ));
Generate_gp stage_1_gp1     (.i_pre_g   (stage0_g[4]    ), .i_pre_p (stage0_p[4]    ), .i_g (stage0_g[5]    ), .i_p (stage0_p[5]    ), .o_g (stage1_g[1]    ), .o_p (stage1_p[1]    ));
Generate_gp stage_1_gp2     (.i_pre_g   (stage0_g[6]    ), .i_pre_p (stage0_p[6]    ), .i_g (stage0_g[7]    ), .i_p (stage0_p[7]    ), .o_g (stage1_g[2]    ), .o_p (stage1_p[2]    ));
Generate_gp stage_1_gp3     (.i_pre_g   (stage0_g[8]    ), .i_pre_p (stage0_p[8]    ), .i_g (stage0_g[9]    ), .i_p (stage0_p[9]    ), .o_g (stage1_g[3]    ), .o_p (stage1_p[3]    ));
Generate_gp stage_1_gp4     (.i_pre_g   (stage0_g[10]   ), .i_pre_p (stage0_p[10]   ), .i_g (stage0_g[11]   ), .i_p (stage0_p[11]   ), .o_g (stage1_g[4]    ), .o_p (stage1_p[4]    ));
Generate_gp stage_1_gp5     (.i_pre_g   (stage0_g[12]   ), .i_pre_p (stage0_p[12]   ), .i_g (stage0_g[13]   ), .i_p (stage0_p[13]   ), .o_g (stage1_g[5]    ), .o_p (stage1_p[5]    ));
Generate_gp stage_1_gp6     (.i_pre_g   (stage0_g[14]   ), .i_pre_p (stage0_p[14]   ), .i_g (stage0_g[15]   ), .i_p (stage0_p[15]   ), .o_g (stage1_g[6]    ), .o_p (stage1_p[6]    ));
Generate_gp stage_1_gp7     (.i_pre_g   (stage0_g[16]   ), .i_pre_p (stage0_p[16]   ), .i_g (stage0_g[17]   ), .i_p (stage0_p[17]   ), .o_g (stage1_g[7]    ), .o_p (stage1_p[7]    ));
Generate_gp stage_1_gp8     (.i_pre_g   (stage0_g[18]   ), .i_pre_p (stage0_p[18]   ), .i_g (stage0_g[19]   ), .i_p (stage0_p[19]   ), .o_g (stage1_g[8]    ), .o_p (stage1_p[8]    ));
Generate_gp stage_1_gp9     (.i_pre_g   (stage0_g[20]   ), .i_pre_p (stage0_p[20]   ), .i_g (stage0_g[21]   ), .i_p (stage0_p[21]   ), .o_g (stage1_g[9]    ), .o_p (stage1_p[9]    ));
Generate_gp stage_1_gp10    (.i_pre_g   (stage0_g[22]   ), .i_pre_p (stage0_p[22]   ), .i_g (stage0_g[23]   ), .i_p (stage0_p[23]   ), .o_g (stage1_g[10]   ), .o_p (stage1_p[10]   ));

//stage 1 to 2
Generate_gp stage_2_gp0     (.i_pre_g   (stage1_g[1]    ), .i_pre_p (stage1_p[1]    ), .i_g (stage1_g[2]    ), .i_p (stage1_p[2]    ), .o_g (stage2_g[0]    ), .o_p (stage2_p[0]    ));
Generate_gp stage_2_gp1     (.i_pre_g   (stage1_g[3]    ), .i_pre_p (stage1_p[3]    ), .i_g (stage1_g[4]    ), .i_p (stage1_p[4]    ), .o_g (stage2_g[1]    ), .o_p (stage2_p[1]    ));
Generate_gp stage_2_gp2     (.i_pre_g   (stage1_g[5]    ), .i_pre_p (stage1_p[5]    ), .i_g (stage1_g[6]    ), .i_p (stage1_p[6]    ), .o_g (stage2_g[2]    ), .o_p (stage2_p[2]    ));
Generate_gp stage_2_gp3     (.i_pre_g   (stage1_g[7]    ), .i_pre_p (stage1_p[7]    ), .i_g (stage1_g[8]    ), .i_p (stage1_p[8]    ), .o_g (stage2_g[3]    ), .o_p (stage2_p[3]    ));
Generate_gp stage_2_gp4     (.i_pre_g   (stage1_g[9]    ), .i_pre_p (stage1_p[9]    ), .i_g (stage1_g[10]   ), .i_p (stage1_p[10]   ), .o_g (stage2_g[4]    ), .o_p (stage2_p[4]    ));

//stage 2 to 3
Generate_gp stage_3_gp0     (.i_pre_g   (stage2_g[1]    ), .i_pre_p (stage2_p[1]    ), .i_g (stage2_g[2]    ), .i_p (stage2_p[2]    ), .o_g (stage3_g[0]    ), .o_p (stage3_p[0]    ));
Generate_gp stage_3_gp1     (.i_pre_g   (stage2_g[3]    ), .i_pre_p (stage2_p[3]    ), .i_g (stage2_g[4]    ), .i_p (stage2_p[4]    ), .o_g (stage3_g[1]    ), .o_p (stage3_p[1]    ));

//final_g(=G_?:0) = C_o,?
assign  final_g[0] = stage0_g[0];
Generate_g  g1  (.i_pre_g   (final_g[0] ), .i_g (stage0_g[1]    ), .i_p     (stage0_p[1]    ), .o_g (final_g[1]    ));
Generate_g  g2  (.i_pre_g   (final_g[1] ), .i_g (stage0_g[2]    ), .i_p     (stage0_p[2]    ), .o_g (final_g[2]    ));
Generate_g  g3  (.i_pre_g   (final_g[1] ), .i_g (stage1_g[0]    ), .i_p     (stage1_p[0]    ), .o_g (final_g[3]    ));
Generate_g  g4  (.i_pre_g   (final_g[3] ), .i_g (stage0_g[4]    ), .i_p     (stage0_p[4]    ), .o_g (final_g[4]    ));
Generate_g  g5  (.i_pre_g   (final_g[3] ), .i_g (stage1_g[1]    ), .i_p     (stage1_p[1]    ), .o_g (final_g[5]    ));
Generate_g  g6  (.i_pre_g   (final_g[5] ), .i_g (stage0_g[6]    ), .i_p     (stage0_p[6]    ), .o_g (final_g[6]    ));
Generate_g  g7  (.i_pre_g   (final_g[3] ), .i_g (stage2_g[0]    ), .i_p     (stage2_p[0]    ), .o_g (final_g[7]    ));
Generate_g  g8  (.i_pre_g   (final_g[7] ), .i_g (stage0_g[8]    ), .i_p     (stage0_p[8]    ), .o_g (final_g[8]    ));
Generate_g  g9  (.i_pre_g   (final_g[7] ), .i_g (stage1_g[3]    ), .i_p     (stage1_p[3]    ), .o_g (final_g[9]    ));
Generate_g  g10 (.i_pre_g   (final_g[9] ), .i_g (stage0_g[10]   ), .i_p     (stage0_p[10]   ), .o_g (final_g[10]   ));
Generate_g  g11 (.i_pre_g   (final_g[7] ), .i_g (stage2_g[1]    ), .i_p     (stage2_p[1]    ), .o_g (final_g[11]   ));
Generate_g  g12 (.i_pre_g   (final_g[11]), .i_g (stage0_g[12]   ), .i_p     (stage0_p[12]   ), .o_g (final_g[12]   ));
Generate_g  g13 (.i_pre_g   (final_g[11]), .i_g (stage1_g[5]    ), .i_p     (stage1_p[5]    ), .o_g (final_g[13]   ));
Generate_g  g14 (.i_pre_g   (final_g[13]), .i_g (stage0_g[14]   ), .i_p     (stage0_p[14]   ), .o_g (final_g[14]   ));
Generate_g  g15 (.i_pre_g   (final_g[7] ), .i_g (stage3_g[0]    ), .i_p     (stage3_p[0]    ), .o_g (final_g[15]   ));
Generate_g  g16 (.i_pre_g   (final_g[15]), .i_g (stage0_g[16]   ), .i_p     (stage0_p[16]   ), .o_g (final_g[16]   ));
Generate_g  g17 (.i_pre_g   (final_g[15]), .i_g (stage1_g[7]    ), .i_p     (stage1_p[7]    ), .o_g (final_g[17]   ));
Generate_g  g18 (.i_pre_g   (final_g[17]), .i_g (stage0_g[18]   ), .i_p     (stage0_p[18]   ), .o_g (final_g[18]   ));
Generate_g  g19 (.i_pre_g   (final_g[15]), .i_g (stage2_g[3]    ), .i_p     (stage2_p[3]    ), .o_g (final_g[19]   ));
Generate_g  g20 (.i_pre_g   (final_g[19]), .i_g (stage0_g[20]   ), .i_p     (stage0_p[20]   ), .o_g (final_g[20]   ));
Generate_g  g21 (.i_pre_g   (final_g[19]), .i_g (stage1_g[9]    ), .i_p     (stage1_p[9]    ), .o_g (final_g[21]   ));
Generate_g  g22 (.i_pre_g   (final_g[21]), .i_g (stage0_g[22]   ), .i_p     (stage0_p[22]   ), .o_g (final_g[22]   ));
Generate_g  g23 (.i_pre_g   (final_g[15]), .i_g (stage3_g[1]    ), .i_p     (stage3_p[1]    ), .o_g (final_g[23]   ));

//sum
assign  sum = stage0_p[23:1] ^ final_g[22:0];
assign  o_result = {final_g[23], sum, stage0_p[0]};

endmodule
