`timescale 1ns / 1ps

module Brent_Kung_48bits(
    input   wire    [47 :   0]  i_A     ,
    input   wire    [47 :   0]  i_B     ,
    output  wire    [48 :   0]  o_result
);

wire    [47 :   0]  stage0_g    ;
wire    [47 :   0]  stage0_p    ;
wire    [22 :   0]  stage1_g    ;
wire    [22 :   0]  stage1_p    ;
wire    [10 :   0]  stage2_g    ;
wire    [10 :   0]  stage2_p    ;
wire    [4  :   0]  stage3_g    ;
wire    [4  :   0]  stage3_p    ;
wire                stage4_g    ;
wire                stage4_p    ;
wire    [47 :   0]  final_g     ;
wire    [46 :   0]  sum         ;

assign  stage0_g = i_A & i_B;
assign  stage0_p = i_A ^ i_B;

//stage 0 to 1
Generate_gp stage_1_gp0     (.i_pre_g   (stage0_g[2]    ), .i_pre_p (stage0_p[2]    ), .i_g (stage0_g[3]    ), .i_p (stage0_p[3]    ), .o_g (stage1_g[0]    ), .o_p (stage1_p[0]    ));
Generate_gp stage_1_gp1     (.i_pre_g   (stage0_g[4]    ), .i_pre_p (stage0_p[4]    ), .i_g (stage0_g[5]    ), .i_p (stage0_p[5]    ), .o_g (stage1_g[1]    ), .o_p (stage1_p[1]    ));
Generate_gp stage_1_gp2     (.i_pre_g   (stage0_g[6]    ), .i_pre_p (stage0_p[6]    ), .i_g (stage0_g[7]    ), .i_p (stage0_p[7]    ), .o_g (stage1_g[2]    ), .o_p (stage1_p[2]    ));
Generate_gp stage_1_gp3     (.i_pre_g   (stage0_g[8]    ), .i_pre_p (stage0_p[8]    ), .i_g (stage0_g[9]    ), .i_p (stage0_p[9]    ), .o_g (stage1_g[3]    ), .o_p (stage1_p[3]    ));
Generate_gp stage_1_gp4     (.i_pre_g   (stage0_g[10]   ), .i_pre_p (stage0_p[10]   ), .i_g (stage0_g[11]   ), .i_p (stage0_p[11]   ), .o_g (stage1_g[4]    ), .o_p (stage1_p[4]    ));
Generate_gp stage_1_gp5     (.i_pre_g   (stage0_g[12]   ), .i_pre_p (stage0_p[12]   ), .i_g (stage0_g[13]   ), .i_p (stage0_p[13]   ), .o_g (stage1_g[5]    ), .o_p (stage1_p[5]    ));
Generate_gp stage_1_gp6     (.i_pre_g   (stage0_g[14]   ), .i_pre_p (stage0_p[14]   ), .i_g (stage0_g[15]   ), .i_p (stage0_p[15]   ), .o_g (stage1_g[6]    ), .o_p (stage1_p[6]    ));
Generate_gp stage_1_gp7     (.i_pre_g   (stage0_g[16]   ), .i_pre_p (stage0_p[16]   ), .i_g (stage0_g[17]   ), .i_p (stage0_p[17]   ), .o_g (stage1_g[7]    ), .o_p (stage1_p[7]    ));
Generate_gp stage_1_gp8     (.i_pre_g   (stage0_g[18]   ), .i_pre_p (stage0_p[18]   ), .i_g (stage0_g[19]   ), .i_p (stage0_p[19]   ), .o_g (stage1_g[8]    ), .o_p (stage1_p[8]    ));
Generate_gp stage_1_gp9     (.i_pre_g   (stage0_g[20]   ), .i_pre_p (stage0_p[20]   ), .i_g (stage0_g[21]   ), .i_p (stage0_p[21]   ), .o_g (stage1_g[9]    ), .o_p (stage1_p[9]    ));
Generate_gp stage_1_gp10    (.i_pre_g   (stage0_g[22]   ), .i_pre_p (stage0_p[22]   ), .i_g (stage0_g[23]   ), .i_p (stage0_p[23]   ), .o_g (stage1_g[10]   ), .o_p (stage1_p[10]   ));
Generate_gp stage_1_gp11    (.i_pre_g   (stage0_g[24]   ), .i_pre_p (stage0_p[24]   ), .i_g (stage0_g[25]   ), .i_p (stage0_p[25]   ), .o_g (stage1_g[11]   ), .o_p (stage1_p[11]   ));
Generate_gp stage_1_gp12    (.i_pre_g   (stage0_g[26]   ), .i_pre_p (stage0_p[26]   ), .i_g (stage0_g[27]   ), .i_p (stage0_p[27]   ), .o_g (stage1_g[12]   ), .o_p (stage1_p[12]   ));
Generate_gp stage_1_gp13    (.i_pre_g   (stage0_g[28]   ), .i_pre_p (stage0_p[28]   ), .i_g (stage0_g[29]   ), .i_p (stage0_p[29]   ), .o_g (stage1_g[13]   ), .o_p (stage1_p[13]   ));
Generate_gp stage_1_gp14    (.i_pre_g   (stage0_g[30]   ), .i_pre_p (stage0_p[30]   ), .i_g (stage0_g[31]   ), .i_p (stage0_p[31]   ), .o_g (stage1_g[14]   ), .o_p (stage1_p[14]   ));
Generate_gp stage_1_gp15    (.i_pre_g   (stage0_g[32]   ), .i_pre_p (stage0_p[32]   ), .i_g (stage0_g[33]   ), .i_p (stage0_p[33]   ), .o_g (stage1_g[15]   ), .o_p (stage1_p[15]   ));
Generate_gp stage_1_gp16    (.i_pre_g   (stage0_g[34]   ), .i_pre_p (stage0_p[34]   ), .i_g (stage0_g[35]   ), .i_p (stage0_p[35]   ), .o_g (stage1_g[16]   ), .o_p (stage1_p[16]   ));
Generate_gp stage_1_gp17    (.i_pre_g   (stage0_g[36]   ), .i_pre_p (stage0_p[36]   ), .i_g (stage0_g[37]   ), .i_p (stage0_p[37]   ), .o_g (stage1_g[17]   ), .o_p (stage1_p[17]   ));
Generate_gp stage_1_gp18    (.i_pre_g   (stage0_g[38]   ), .i_pre_p (stage0_p[38]   ), .i_g (stage0_g[39]   ), .i_p (stage0_p[39]   ), .o_g (stage1_g[18]   ), .o_p (stage1_p[18]   ));
Generate_gp stage_1_gp19    (.i_pre_g   (stage0_g[40]   ), .i_pre_p (stage0_p[40]   ), .i_g (stage0_g[41]   ), .i_p (stage0_p[41]   ), .o_g (stage1_g[19]   ), .o_p (stage1_p[19]   ));
Generate_gp stage_1_gp20    (.i_pre_g   (stage0_g[42]   ), .i_pre_p (stage0_p[42]   ), .i_g (stage0_g[43]   ), .i_p (stage0_p[43]   ), .o_g (stage1_g[20]   ), .o_p (stage1_p[20]   ));
Generate_gp stage_1_gp21    (.i_pre_g   (stage0_g[44]   ), .i_pre_p (stage0_p[44]   ), .i_g (stage0_g[45]   ), .i_p (stage0_p[45]   ), .o_g (stage1_g[21]   ), .o_p (stage1_p[21]   ));
Generate_gp stage_1_gp22    (.i_pre_g   (stage0_g[46]   ), .i_pre_p (stage0_p[46]   ), .i_g (stage0_g[47]   ), .i_p (stage0_p[47]   ), .o_g (stage1_g[22]   ), .o_p (stage1_p[22]   ));

//stage 1 to 2
Generate_gp stage_2_gp0     (.i_pre_g   (stage1_g[1]    ), .i_pre_p (stage1_p[1]    ), .i_g (stage1_g[2]    ), .i_p (stage1_p[2]    ), .o_g (stage2_g[0]    ), .o_p (stage2_p[0]    ));
Generate_gp stage_2_gp1     (.i_pre_g   (stage1_g[3]    ), .i_pre_p (stage1_p[3]    ), .i_g (stage1_g[4]    ), .i_p (stage1_p[4]    ), .o_g (stage2_g[1]    ), .o_p (stage2_p[1]    ));
Generate_gp stage_2_gp2     (.i_pre_g   (stage1_g[5]    ), .i_pre_p (stage1_p[5]    ), .i_g (stage1_g[6]    ), .i_p (stage1_p[6]    ), .o_g (stage2_g[2]    ), .o_p (stage2_p[2]    ));
Generate_gp stage_2_gp3     (.i_pre_g   (stage1_g[7]    ), .i_pre_p (stage1_p[7]    ), .i_g (stage1_g[8]    ), .i_p (stage1_p[8]    ), .o_g (stage2_g[3]    ), .o_p (stage2_p[3]    ));
Generate_gp stage_2_gp4     (.i_pre_g   (stage1_g[9]    ), .i_pre_p (stage1_p[9]    ), .i_g (stage1_g[10]   ), .i_p (stage1_p[10]   ), .o_g (stage2_g[4]    ), .o_p (stage2_p[4]    ));
Generate_gp stage_2_gp5     (.i_pre_g   (stage1_g[11]   ), .i_pre_p (stage1_p[11]   ), .i_g (stage1_g[12]   ), .i_p (stage1_p[12]   ), .o_g (stage2_g[5]    ), .o_p (stage2_p[5]    ));
Generate_gp stage_2_gp6     (.i_pre_g   (stage1_g[13]   ), .i_pre_p (stage1_p[13]   ), .i_g (stage1_g[14]   ), .i_p (stage1_p[14]   ), .o_g (stage2_g[6]    ), .o_p (stage2_p[6]    ));
Generate_gp stage_2_gp7     (.i_pre_g   (stage1_g[15]   ), .i_pre_p (stage1_p[15]   ), .i_g (stage1_g[16]   ), .i_p (stage1_p[16]   ), .o_g (stage2_g[7]    ), .o_p (stage2_p[7]    ));
Generate_gp stage_2_gp8     (.i_pre_g   (stage1_g[17]   ), .i_pre_p (stage1_p[17]   ), .i_g (stage1_g[18]   ), .i_p (stage1_p[18]   ), .o_g (stage2_g[8]    ), .o_p (stage2_p[8]    ));
Generate_gp stage_2_gp9     (.i_pre_g   (stage1_g[19]   ), .i_pre_p (stage1_p[19]   ), .i_g (stage1_g[20]   ), .i_p (stage1_p[20]   ), .o_g (stage2_g[9]    ), .o_p (stage2_p[9]    ));
Generate_gp stage_2_gp10    (.i_pre_g   (stage1_g[21]   ), .i_pre_p (stage1_p[21]   ), .i_g (stage1_g[22]   ), .i_p (stage1_p[22]   ), .o_g (stage2_g[10]   ), .o_p (stage2_p[10]   ));

//stage 2 to 3
Generate_gp stage_3_gp0     (.i_pre_g   (stage2_g[1]    ), .i_pre_p (stage2_p[1]    ), .i_g (stage2_g[2]    ), .i_p (stage2_p[2]    ), .o_g (stage3_g[0]    ), .o_p (stage3_p[0]    ));
Generate_gp stage_3_gp1     (.i_pre_g   (stage2_g[3]    ), .i_pre_p (stage2_p[3]    ), .i_g (stage2_g[4]    ), .i_p (stage2_p[4]    ), .o_g (stage3_g[1]    ), .o_p (stage3_p[1]    ));
Generate_gp stage_3_gp2     (.i_pre_g   (stage2_g[5]    ), .i_pre_p (stage2_p[5]    ), .i_g (stage2_g[6]    ), .i_p (stage2_p[6]    ), .o_g (stage3_g[2]    ), .o_p (stage3_p[2]    ));
Generate_gp stage_3_gp3     (.i_pre_g   (stage2_g[7]    ), .i_pre_p (stage2_p[7]    ), .i_g (stage2_g[8]    ), .i_p (stage2_p[8]    ), .o_g (stage3_g[3]    ), .o_p (stage3_p[3]    ));
Generate_gp stage_3_gp4     (.i_pre_g   (stage2_g[9]    ), .i_pre_p (stage2_p[9]    ), .i_g (stage2_g[10]   ), .i_p (stage2_p[10]   ), .o_g (stage3_g[4]    ), .o_p (stage3_p[4]    ));

//stage 3 to 4
Generate_gp stage_4_gp0     (.i_pre_g   (stage3_g[1]    ), .i_pre_p (stage3_p[1]    ), .i_g (stage3_g[2]    ), .i_p (stage3_p[2]    ), .o_g (stage4_g       ), .o_p (stage4_p       ));

//final_g(=G_?:0) = C_o,?
assign  final_g[0] = stage0_g[0];
Generate_g  g1  (.i_pre_g   (final_g[0] ), .i_g (stage0_g[1]    ), .i_p     (stage0_p[1]    ), .o_g (final_g[1]    ));
Generate_g  g2  (.i_pre_g   (final_g[1] ), .i_g (stage0_g[2]    ), .i_p     (stage0_p[2]    ), .o_g (final_g[2]    ));
Generate_g  g3  (.i_pre_g   (final_g[1] ), .i_g (stage1_g[0]    ), .i_p     (stage1_p[0]    ), .o_g (final_g[3]    ));
Generate_g  g4  (.i_pre_g   (final_g[3] ), .i_g (stage0_g[4]    ), .i_p     (stage0_p[4]    ), .o_g (final_g[4]    ));
Generate_g  g5  (.i_pre_g   (final_g[3] ), .i_g (stage1_g[1]    ), .i_p     (stage1_p[1]    ), .o_g (final_g[5]    ));
Generate_g  g6  (.i_pre_g   (final_g[5] ), .i_g (stage0_g[6]    ), .i_p     (stage0_p[6]    ), .o_g (final_g[6]    ));
Generate_g  g7  (.i_pre_g   (final_g[3] ), .i_g (stage2_g[0]    ), .i_p     (stage2_p[0]    ), .o_g (final_g[7]    ));
Generate_g  g8  (.i_pre_g   (final_g[7] ), .i_g (stage0_g[8]    ), .i_p     (stage0_p[8]    ), .o_g (final_g[8]    ));
Generate_g  g9  (.i_pre_g   (final_g[7] ), .i_g (stage1_g[3]    ), .i_p     (stage1_p[3]    ), .o_g (final_g[9]    ));
Generate_g  g10 (.i_pre_g   (final_g[9] ), .i_g (stage0_g[10]   ), .i_p     (stage0_p[10]   ), .o_g (final_g[10]   ));
Generate_g  g11 (.i_pre_g   (final_g[7] ), .i_g (stage2_g[1]    ), .i_p     (stage2_p[1]    ), .o_g (final_g[11]   ));
Generate_g  g12 (.i_pre_g   (final_g[11]), .i_g (stage0_g[12]   ), .i_p     (stage0_p[12]   ), .o_g (final_g[12]   ));
Generate_g  g13 (.i_pre_g   (final_g[11]), .i_g (stage1_g[5]    ), .i_p     (stage1_p[5]    ), .o_g (final_g[13]   ));
Generate_g  g14 (.i_pre_g   (final_g[13]), .i_g (stage0_g[14]   ), .i_p     (stage0_p[14]   ), .o_g (final_g[14]   ));
Generate_g  g15 (.i_pre_g   (final_g[7] ), .i_g (stage3_g[0]    ), .i_p     (stage3_p[0]    ), .o_g (final_g[15]   ));
Generate_g  g16 (.i_pre_g   (final_g[15]), .i_g (stage0_g[16]   ), .i_p     (stage0_p[16]   ), .o_g (final_g[16]   ));
Generate_g  g17 (.i_pre_g   (final_g[15]), .i_g (stage1_g[7]    ), .i_p     (stage1_p[7]    ), .o_g (final_g[17]   ));
Generate_g  g18 (.i_pre_g   (final_g[17]), .i_g (stage0_g[18]   ), .i_p     (stage0_p[18]   ), .o_g (final_g[18]   ));
Generate_g  g19 (.i_pre_g   (final_g[15]), .i_g (stage2_g[3]    ), .i_p     (stage2_p[3]    ), .o_g (final_g[19]   ));
Generate_g  g20 (.i_pre_g   (final_g[19]), .i_g (stage0_g[20]   ), .i_p     (stage0_p[20]   ), .o_g (final_g[20]   ));
Generate_g  g21 (.i_pre_g   (final_g[19]), .i_g (stage1_g[9]    ), .i_p     (stage1_p[9]    ), .o_g (final_g[21]   ));
Generate_g  g22 (.i_pre_g   (final_g[21]), .i_g (stage0_g[22]   ), .i_p     (stage0_p[22]   ), .o_g (final_g[22]   ));
Generate_g  g23 (.i_pre_g   (final_g[15]), .i_g (stage3_g[1]    ), .i_p     (stage3_p[1]    ), .o_g (final_g[23]   ));

Generate_g  g24 (.i_pre_g   (final_g[23]), .i_g (stage0_g[24]   ), .i_p     (stage0_p[24]   ), .o_g (final_g[24]   ));
Generate_g  g25 (.i_pre_g   (final_g[23]), .i_g (stage1_g[11]   ), .i_p     (stage1_p[11]   ), .o_g (final_g[25]   ));
Generate_g  g26 (.i_pre_g   (final_g[25]), .i_g (stage0_g[26]   ), .i_p     (stage0_p[26]   ), .o_g (final_g[26]   ));
Generate_g  g27 (.i_pre_g   (final_g[23]), .i_g (stage2_g[5]    ), .i_p     (stage2_p[5]    ), .o_g (final_g[27]   ));
Generate_g  g28 (.i_pre_g   (final_g[27]), .i_g (stage0_g[28]   ), .i_p     (stage0_p[28]   ), .o_g (final_g[28]   ));
Generate_g  g29 (.i_pre_g   (final_g[27]), .i_g (stage1_g[13]   ), .i_p     (stage1_p[13]   ), .o_g (final_g[29]   ));
Generate_g  g30 (.i_pre_g   (final_g[29]), .i_g (stage0_g[30]   ), .i_p     (stage0_p[30]   ), .o_g (final_g[30]   ));
Generate_g  g31 (.i_pre_g   (final_g[15]), .i_g (stage4_g       ), .i_p     (stage4_p       ), .o_g (final_g[31]   ));
Generate_g  g32 (.i_pre_g   (final_g[31]), .i_g (stage0_g[32]   ), .i_p     (stage0_p[32]   ), .o_g (final_g[32]   ));
Generate_g  g33 (.i_pre_g   (final_g[31]), .i_g (stage1_g[15]   ), .i_p     (stage1_p[15]   ), .o_g (final_g[33]   ));
Generate_g  g34 (.i_pre_g   (final_g[33]), .i_g (stage0_g[34]   ), .i_p     (stage0_p[34]   ), .o_g (final_g[34]   ));
Generate_g  g35 (.i_pre_g   (final_g[31]), .i_g (stage2_g[7]    ), .i_p     (stage2_p[7]    ), .o_g (final_g[35]   ));
Generate_g  g36 (.i_pre_g   (final_g[35]), .i_g (stage0_g[36]   ), .i_p     (stage0_p[36]   ), .o_g (final_g[36]   ));
Generate_g  g37 (.i_pre_g   (final_g[35]), .i_g (stage1_g[17]   ), .i_p     (stage1_p[17]   ), .o_g (final_g[37]   ));
Generate_g  g38 (.i_pre_g   (final_g[37]), .i_g (stage0_g[38]   ), .i_p     (stage0_p[38]   ), .o_g (final_g[38]   ));
Generate_g  g39 (.i_pre_g   (final_g[31]), .i_g (stage3_g[3]    ), .i_p     (stage3_p[3]    ), .o_g (final_g[39]   ));
Generate_g  g40 (.i_pre_g   (final_g[39]), .i_g (stage0_g[40]   ), .i_p     (stage0_p[40]   ), .o_g (final_g[40]   ));
Generate_g  g41 (.i_pre_g   (final_g[39]), .i_g (stage1_g[19]   ), .i_p     (stage1_p[19]   ), .o_g (final_g[41]   ));
Generate_g  g42 (.i_pre_g   (final_g[41]), .i_g (stage0_g[42]   ), .i_p     (stage0_p[42]   ), .o_g (final_g[42]   ));
Generate_g  g43 (.i_pre_g   (final_g[39]), .i_g (stage2_g[9]    ), .i_p     (stage2_p[9]    ), .o_g (final_g[43]   ));
Generate_g  g44 (.i_pre_g   (final_g[43]), .i_g (stage0_g[44]   ), .i_p     (stage0_p[44]   ), .o_g (final_g[44]   ));
Generate_g  g45 (.i_pre_g   (final_g[43]), .i_g (stage1_g[21]   ), .i_p     (stage1_p[21]   ), .o_g (final_g[45]   ));
Generate_g  g46 (.i_pre_g   (final_g[45]), .i_g (stage0_g[46]   ), .i_p     (stage0_p[46]   ), .o_g (final_g[46]   ));
Generate_g  g47 (.i_pre_g   (final_g[39]), .i_g (stage3_g[4]    ), .i_p     (stage3_p[4]    ), .o_g (final_g[47]   ));


//sum
assign  sum = stage0_p[47:1] ^ final_g[46:0];
assign  o_result = {final_g[47], sum, stage0_p[0]};

endmodule
