`timescale 1ns / 1ps

module Carry_Save_Adder(
    input   wire                clk         ,
    input   wire                resetn      ,
    input   wire    [23 :   0]  i_B         ,
    input   wire    [23 :   0]  i_A         ,
    output  wire    [47 :   0]  o_result
);

wire    [47 :   0]  operand_0   ;
wire    [47 :   0]  operand_1   ;
wire    [47 :   0]  operand_2   ;
wire    [47 :   0]  operand_3   ;
wire    [47 :   0]  operand_4   ;
wire    [47 :   0]  operand_5   ;
wire    [47 :   0]  operand_6   ;
wire    [47 :   0]  operand_7   ;
wire    [47 :   0]  operand_8   ;
wire    [47 :   0]  operand_9   ;
wire    [47 :   0]  operand_10  ;
wire    [47 :   0]  operand_11  ;
wire    [47 :   0]  operand_12  ;

wire    [47 :   0]  shift_operand_0 ;
wire    [47 :   0]  shift_operand_1 ;
wire    [47 :   0]  shift_operand_2 ;
wire    [47 :   0]  shift_operand_3 ;
wire    [47 :   0]  shift_operand_4 ;
wire    [47 :   0]  shift_operand_5 ;
wire    [47 :   0]  shift_operand_6 ;
wire    [47 :   0]  shift_operand_7 ;
wire    [47 :   0]  shift_operand_8 ;
wire    [47 :   0]  shift_operand_9 ;
wire    [47 :   0]  shift_operand_10;
wire    [47 :   0]  shift_operand_11;
wire    [47 :   0]  shift_operand_12;

wire    [47 :   0]  sum_1   , cout_1    ;
wire    [47 :   0]  sum_2   , cout_2    ;
wire    [47 :   0]  sum_3   , cout_3    ;
wire    [47 :   0]  sum_4   , cout_4    ;
wire    [47 :   0]  sum_5   , cout_5    ;
wire    [47 :   0]  sum_6   , cout_6    ;
wire    [47 :   0]  sum_7   , cout_7    ;
wire    [47 :   0]  sum_8   , cout_8    ;
wire    [47 :   0]  sum_9   , cout_9    ;
wire    [47 :   0]  sum_10  , cout_10   ;
wire    [47 :   0]  sum_11  , cout_11   ;
wire    [47 :   0]  trans_cout_11       ;

reg     [47 :   0]  r_sum_6 , r_cout_6;
reg     [47 :   0]  r_shift_operand_8;
reg     [47 :   0]  r_shift_operand_9;
reg     [47 :   0]  r_shift_operand_10;
reg     [47 :   0]  r_shift_operand_11;
reg     [47 :   0]  r_shift_operand_12;



Radix4_Booth RB0    (.i_A(i_A), .i_B({i_B[1:0], 1'b0}), .o_result(operand_0 ));
Radix4_Booth RB1    (.i_A(i_A), .i_B(i_B[3  :1   ]),    .o_result(operand_1 ));
Radix4_Booth RB2    (.i_A(i_A), .i_B(i_B[5  :3   ]),    .o_result(operand_2 ));
Radix4_Booth RB3    (.i_A(i_A), .i_B(i_B[7  :5   ]),    .o_result(operand_3 ));
Radix4_Booth RB4    (.i_A(i_A), .i_B(i_B[9  :7   ]),    .o_result(operand_4 ));
Radix4_Booth RB5    (.i_A(i_A), .i_B(i_B[11 :9   ]),    .o_result(operand_5 ));
Radix4_Booth RB6    (.i_A(i_A), .i_B(i_B[13 :11  ]),    .o_result(operand_6 ));
Radix4_Booth RB7    (.i_A(i_A), .i_B(i_B[15 :13  ]),    .o_result(operand_7 ));
Radix4_Booth RB8    (.i_A(i_A), .i_B(i_B[17 :15  ]),    .o_result(operand_8 ));
Radix4_Booth RB9    (.i_A(i_A), .i_B(i_B[19 :17  ]),    .o_result(operand_9 ));
Radix4_Booth RB10   (.i_A(i_A), .i_B(i_B[21 :19  ]),    .o_result(operand_10));
Radix4_Booth RB11   (.i_A(i_A), .i_B(i_B[23 :21  ]),    .o_result(operand_11));
Radix4_Booth RB12   (.i_A(i_A), .i_B({2'b0, i_B[23]}),  .o_result(operand_12));

assign  shift_operand_0     = operand_0     << 0    ;
assign  shift_operand_1     = operand_1     << 2    ;
assign  shift_operand_2     = operand_2     << 4    ;
assign  shift_operand_3     = operand_3     << 6    ;
assign  shift_operand_4     = operand_4     << 8    ;
assign  shift_operand_5     = operand_5     << 10   ;
assign  shift_operand_6     = operand_6     << 12   ;
assign  shift_operand_7     = operand_7     << 14   ;
assign  shift_operand_8     = operand_8     << 16   ;
assign  shift_operand_9     = operand_9     << 18   ;
assign  shift_operand_10    = operand_10    << 20   ;
assign  shift_operand_11    = operand_11    << 22   ;
assign  shift_operand_12    = operand_12    << 24   ;


//stage1
genvar a;
generate
    for(a = 0; a < 48; a = a + 1) begin : CSA_1
        full_adder fa1  (.i_A(shift_operand_0[a]), .i_B(shift_operand_1[a]), .i_cin(shift_operand_2[a]  ), .o_sum(sum_1[a]), .o_cout(cout_1[a]));
    end
endgenerate

full_adder fa2_0    (.i_A(shift_operand_3 [0]), .i_B(sum_1[0]   ), .i_cin(1'b0), .o_sum(sum_2 [0]), .o_cout(cout_2 [0]));
full_adder fa3_0    (.i_A(shift_operand_4 [0]), .i_B(sum_2[0]   ), .i_cin(1'b0), .o_sum(sum_3 [0]), .o_cout(cout_3 [0]));
full_adder fa4_0    (.i_A(shift_operand_5 [0]), .i_B(sum_3[0]   ), .i_cin(1'b0), .o_sum(sum_4 [0]), .o_cout(cout_4 [0]));
full_adder fa5_0    (.i_A(shift_operand_6 [0]), .i_B(sum_4[0]   ), .i_cin(1'b0), .o_sum(sum_5 [0]), .o_cout(cout_5 [0]));
full_adder fa6_0    (.i_A(shift_operand_7 [0]), .i_B(sum_5[0]   ), .i_cin(1'b0), .o_sum(sum_6 [0]), .o_cout(cout_6 [0]));
full_adder fa7_0    (.i_A(r_shift_operand_8 [0]), .i_B(r_sum_6[0] ), .i_cin(1'b0), .o_sum(sum_7 [0]), .o_cout(cout_7 [0]));
full_adder fa8_0    (.i_A(r_shift_operand_9 [0]), .i_B(sum_7[0]   ), .i_cin(1'b0), .o_sum(sum_8 [0]), .o_cout(cout_8 [0]));
full_adder fa9_0    (.i_A(r_shift_operand_10[0]), .i_B(sum_8[0]   ), .i_cin(1'b0), .o_sum(sum_9 [0]), .o_cout(cout_9 [0]));
full_adder fa10_0   (.i_A(r_shift_operand_11[0]), .i_B(sum_9[0]   ), .i_cin(1'b0), .o_sum(sum_10[0]), .o_cout(cout_10[0]));
full_adder fa11_0   (.i_A(r_shift_operand_12[0]), .i_B(sum_10[0]  ), .i_cin(1'b0), .o_sum(sum_11[0]), .o_cout(cout_11[0]));

genvar b;
generate
    for(b = 1; b < 48; b = b + 1) begin : CSA_2
        full_adder fa2  (.i_A(shift_operand_3 [b]), .i_B(sum_1  [b]), .i_cin(cout_1   [b - 1]), .o_sum(sum_2   [b]), .o_cout(cout_2   [b]));
        full_adder fa3  (.i_A(shift_operand_4 [b]), .i_B(sum_2  [b]), .i_cin(cout_2   [b - 1]), .o_sum(sum_3   [b]), .o_cout(cout_3   [b]));
        full_adder fa4  (.i_A(shift_operand_5 [b]), .i_B(sum_3  [b]), .i_cin(cout_3   [b - 1]), .o_sum(sum_4   [b]), .o_cout(cout_4   [b]));
        full_adder fa5  (.i_A(shift_operand_6 [b]), .i_B(sum_4  [b]), .i_cin(cout_4   [b - 1]), .o_sum(sum_5   [b]), .o_cout(cout_5   [b]));
        full_adder fa6  (.i_A(shift_operand_7 [b]), .i_B(sum_5  [b]), .i_cin(cout_5   [b - 1]), .o_sum(sum_6   [b]), .o_cout(cout_6   [b]));
        full_adder fa7  (.i_A(r_shift_operand_8 [b]), .i_B(r_sum_6[b]), .i_cin(r_cout_6 [b - 1]), .o_sum(sum_7   [b]), .o_cout(cout_7   [b]));
        full_adder fa8  (.i_A(r_shift_operand_9 [b]), .i_B(sum_7  [b]), .i_cin(cout_7   [b - 1]), .o_sum(sum_8   [b]), .o_cout(cout_8   [b]));
        full_adder fa9  (.i_A(r_shift_operand_10[b]), .i_B(sum_8  [b]), .i_cin(cout_8   [b - 1]), .o_sum(sum_9   [b]), .o_cout(cout_9   [b]));
        full_adder fa10 (.i_A(r_shift_operand_11[b]), .i_B(sum_9  [b]), .i_cin(cout_9   [b - 1]), .o_sum(sum_10  [b]), .o_cout(cout_10  [b]));
        full_adder fa11 (.i_A(r_shift_operand_12[b]), .i_B(sum_10 [b]), .i_cin(cout_10  [b - 1]), .o_sum(sum_11  [b]), .o_cout(cout_11  [b]));
    end
endgenerate

always @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        r_sum_6     <= 48'b0;
        r_cout_6    <= 48'b0;
        r_shift_operand_8 <= 48'b0;
        r_shift_operand_9 <= 48'b0;
        r_shift_operand_10 <= 48'b0;
        r_shift_operand_11 <= 48'b0;
        r_shift_operand_12 <= 48'b0;
    end
    else begin
        r_sum_6     <= sum_6;
        r_cout_6    <= cout_6;
        r_shift_operand_8 <= shift_operand_8;
        r_shift_operand_9 <= shift_operand_9;
        r_shift_operand_10 <= shift_operand_10;
        r_shift_operand_11 <= shift_operand_11;
        r_shift_operand_12 <= shift_operand_12;
    end
end

assign  trans_cout_11 = cout_11 << 1;

Brent_Kung_48bits BK48(
    .i_A        (trans_cout_11  ),
    .i_B        (sum_11         ),
    .o_result   (o_result       )
);

//assign  o_result = (cout_11 << 1) + sum_11;

endmodule
