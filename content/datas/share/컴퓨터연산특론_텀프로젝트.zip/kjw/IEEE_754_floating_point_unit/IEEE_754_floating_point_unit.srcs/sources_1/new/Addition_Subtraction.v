`timescale 1ns / 1ps

module Addition_Subtraction(
    input   wire                clk             ,
    input   wire                resetn          ,
    input   wire    [31 :   0]  i_operand_A     ,
    input   wire    [31 :   0]  i_operand_B     ,
    input   wire                i_sel_addsub    ,
    output  wire                o_exception     ,
    output  wire    [31 :   0]  o_result
);

wire                sign                        ;
wire                cmp_abs                     ;
wire                sel_addsub                  ;
wire                check_exponent              ;
wire                overflow                    ;
wire                underflow                   ;
wire                shift_underflow             ;
wire                zero                        ;

wire    [31 :   0]  operand_A                   ;
wire    [31 :   0]  operand_B                   ;
wire    [7  :   0]  exponent_A                  ;
wire    [7  :   0]  exponent_B                  ;
wire    [22 :   0]  fraction_A                  ;
wire    [22 :   0]  fraction_B                  ;
wire    [23 :   0]  significand_A               ;
wire    [23 :   0]  significand_B               ;
wire    [7  :   0]  trans_exponent_B            ;
wire    [23 :   0]  trans_significand_B         ;
wire    [7  :   0]  cmp_exponent                ;

wire    [24 :   0]  add_significand             ;
wire    [22 :   0]  add_fraction                ;
wire    [7  :   0]  add_exponent                ;

wire    [23 :   0]  complement_significand_B    ;
wire    [23 :   0]  bk_significand_B            ;
wire    [24 :   0]  bk_result                   ;
wire    [24 :   0]  sub_significand             ;
wire    [7  :   0]  norm_exponent               ;
wire    [24 :   0]  norm_significand            ; 
wire    [22 :   0]  norm_fraction               ;

reg     [31 :   0]  r_result                    ;


//크기 비교 후 정렬
assign  {cmp_abs, operand_A, operand_B} = (i_operand_A[30:0] < i_operand_B[30:0]) ? {1'b1, i_operand_B, i_operand_A} : {1'b0, i_operand_A, i_operand_B};

assign  exponent_A = operand_A[30:23];
assign  exponent_B = operand_B[30:23];
assign  fraction_A = operand_A[22:0];
assign  fraction_B = operand_B[22:0];


//실제로 적용할 연산 타입 결정
//i_sel_addsub가 덧셈이고 operand의 부호가 같으면 덧셈
//i_sel_addsub가 덧셈이고 operand의 부호가 다르면 뺄셈
//i_sel_addsub가 뺄셈이고 operand의 부호가 같으면 뺄셈
//i_sel_addsub가 덧셈이고 operand의 부호가 다르면 덧셈
assign  sel_addsub = i_sel_addsub ? ~(operand_A[31] ^ operand_B[31]) : (operand_A[31] ^ operand_B[31]);

//부호 결정
assign  sign = i_sel_addsub ? (cmp_abs ? ~operand_A[31] : operand_A[31]) : operand_A[31];

//normalize와 denormalize
assign  significand_A = (|exponent_A) ? {1'b1, fraction_A} : {1'b0, fraction_A};
assign  significand_B = (|exponent_B) ? {1'b1, fraction_B} : {1'b0, fraction_B};

//지수 크기 맞추기
assign  cmp_exponent = exponent_A - exponent_B;
assign  trans_exponent_B = exponent_B + cmp_exponent;
assign  trans_significand_B = significand_B >> cmp_exponent;

assign  check_exponent = exponent_A == trans_exponent_B;

assign  bk_significand_B = sel_addsub ? complement_significand_B : trans_significand_B;

//덧셈
Brent_Kung_24bits addBK(
    .i_A(significand_A),
    .i_B(bk_significand_B),
    .o_result(bk_result)
);

assign  add_significand = (check_exponent & ~sel_addsub) ? bk_result : 25'b0;
assign  add_fraction = add_significand[24] ? add_significand[23:1] : add_significand[22:0];
assign  add_exponent = add_significand[24] ? exponent_A + 1'b1 : exponent_A;

//뺄셈(보수 및 fraction 보정 필요)
assign  complement_significand_B = ~trans_significand_B + 1'b1;

assign  sub_significand = (check_exponent & sel_addsub) ? bk_result : 25'b0;

Significand_Normalizer SN0(
    .i_exponent      (exponent_A         ),
    .i_significand   (sub_significand    ),
    .o_exponent      (norm_exponent      ),
    .o_significand   (norm_significand   ),
    .o_underflow     (shift_underflow    ),
    .o_zero          (zero               )
);

assign  norm_fraction = norm_significand[22:0];

assign  overflow = &add_exponent | &norm_exponent;
assign  underflow = (|add_exponent == 0) | (|norm_exponent == 0) | shift_underflow;
//결과 출력

assign  o_exception = overflow | underflow;

always @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        r_result <= 32'b0;
    end
    else if(zero) begin
        r_result <= 32'b0;
    end
    else if(sel_addsub) begin
        r_result <= {sign, norm_exponent, norm_fraction};
    end
    else if(!sel_addsub) begin
        r_result <= {sign, add_exponent, add_fraction};
    end
    else begin
        r_result <= 32'b0;
    end
end

        
assign  o_result = r_result;

endmodule