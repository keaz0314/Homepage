`timescale 1ns / 1ps

module full_adder(
    input   wire    i_A     ,
    input   wire    i_B     ,
    input   wire    i_cin   ,
    output  wire    o_sum   ,
    output  wire    o_cout
);

wire    s   ;
wire    c1  ;
wire    c2  ;

half_adder  h0(.i_A(i_A     ), .i_B(i_B), .o_sum(s), .o_cout(c1));
half_adder  h1(.i_A(i_cin   ), .i_B(s), .o_sum(o_sum), .o_cout(c2));

assign  o_cout = c1 | c2;

endmodule
