`timescale 1ns / 1ps

module IEEE754_Standard_Unit(
    input   wire                clk         ,
    input   wire                resetn      ,
    input   wire                i_calc_flag ,
    input   wire    [31 :   0]  i_operand_A ,
    input   wire    [31 :   0]  i_operand_B ,
    input   wire    [1  :   0]  i_operator  ,
    output  wire                o_exception ,
    output  wire                o_valid     ,
    output  wire    [31 :   0]  o_result
);

wire                pre_exception   ;
wire                addsub_exception;
wire                mul_exception   ;
wire    [31 :   0]  addsub_result   ;
wire    [31 :   0]  mul_result      ;

reg                 post_exception  ;
reg                 r_valid         ;
reg     [31 :   0]  result          ;

Pre_Valid PV0(
    .i_operand_A    (i_operand_A[30:0]  ),
    .i_operand_B    (i_operand_B[30:0]  ),
    .o_exception    (pre_exception      )
);

Addition_Subtraction AS0(
    .clk            (clk                ),
    .resetn         (resetn             ),
    .i_operand_A    (i_operand_A        ),
    .i_operand_B    (i_operand_B        ),
    .i_sel_addsub   (i_operator[0]      ),
    .o_exception    (addsub_exception   ),
    .o_result       (addsub_result      )
);

Multiplication M0(
    .clk            (clk            ),
    .resetn         (resetn         ),
    .i_operand_A    (i_operand_A    ),
    .i_operand_B    (i_operand_B    ),
    .i_operator     (i_operator     ),
    .o_exception    (mul_exception  ),
    .o_result       (mul_result     )
);

always  @(*) begin
    casex(i_operator)
        2'b0x   :   begin
                        result = addsub_result;
                        post_exception = addsub_exception;
        end
        2'b10   :   begin
                        result = mul_result;
                        post_exception = mul_exception;
        end
        default :   begin
                        result = 32'b0;
                        post_exception = 1'b0;
        end
    endcase
end

always @(posedge clk or negedge resetn) begin
    if(!resetn) begin
        r_valid <= 1'b0;
    end
    else if(i_calc_flag) begin
        r_valid <= 1'b1;
    end
    else begin
        r_valid <= 1'b0;
    end
end

assign  o_valid = r_valid;
assign  o_result = result;
assign  o_exception = pre_exception | post_exception;

endmodule