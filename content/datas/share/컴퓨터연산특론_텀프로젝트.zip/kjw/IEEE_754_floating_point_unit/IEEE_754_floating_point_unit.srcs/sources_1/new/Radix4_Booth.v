`timescale 1ns / 1ps

module Radix4_Booth(
    input   wire    [23 :   0]  i_A     ,
    input   wire    [2  :   0]  i_B     ,
    output  wire    [47 :   0]  o_result
);

wire    [24 :   0]  A       ;
wire    [47 :   0]  trans_A ;
reg     [47 :   0]  result  ;


assign  trans_A = {24'b0, i_A};

always @(*) begin
    if(i_B == 3'b000 || i_B == 3'b111) begin
        result = 48'b0;
    end
    else if(i_B == 3'b001 || i_B == 3'b010) begin
        result = trans_A;
    end
    else if(i_B == 3'b011) begin
        result = trans_A << 1;
    end
    else if(i_B == 3'b100) begin
        result = (~trans_A + 1) << 1;
    end
    else begin
        result = ~trans_A + 1;
    end
end

assign  o_result = result;

endmodule
