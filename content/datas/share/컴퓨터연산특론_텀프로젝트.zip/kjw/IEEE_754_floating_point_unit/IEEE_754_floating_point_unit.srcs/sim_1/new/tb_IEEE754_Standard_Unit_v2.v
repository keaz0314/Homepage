`timescale 1ns / 1ps

module tb_IEEE754_Standard_Unit_v2();

reg             clk;
reg             resetn;
reg             calc_flag;

reg     [31:0]  operand_A, operand_B;
reg     [31:0]  answer;
reg     [31:0]  r_answer;
reg     [1:0]   operator;
reg     [8*2-1:0]   operator_str;

wire    exception;
wire    valid;
wire    [31:0]  result;
integer file;
integer r;

initial begin
    clk = 1;
    resetn = 1;
    calc_flag = 1;
    file = $fopen("C:/Users/PC/Desktop/kjw/IEEE_754_floating_point_unit/IEEE_754_floating_point_unit.srcs/sources_1/new/test_list.txt", "r");
    if (file == 0) begin
        $display("?��?�� ?��?��");
        $finish;
    end

    while (!$feof(file)) begin
        r = $fscanf(file, "0x%x %s 0x%x = 0x%x\n", operand_A, operator_str, operand_B, answer);
        if (r == 4) begin
            // 문자?�� 비교?��?�� operator �? ?��?��
            if (operator_str == "+")
                operator = 0;
            else if (operator_str == "-")
                operator = 1;
            else if (operator_str == "*")
                operator = 2;
            else begin
                $display("%s", operator_str);
                $finish;
            end
            #20
            calc_flag = 1;
            wait (valid == 1);
            $display("operand_A=0x%08x, operand_B=0x%08x, operator=%0d, answer=0x%08x, your_result=0x%08x", operand_A, operand_B, operator, answer, result);

            case (operator)
                0:  if (result != r_answer) begin
                        $display("add error!");
                    end
                    else begin
                        $display("add correct!");
                    end           
                1: if (result != r_answer) begin
                        $display("sub error!");
                    end
                    else begin
                        $display("sub correct!");
                    end   
                2: if (result != r_answer) begin
                        $display("mul error!");
                    end
                    else begin
                        $display("mul correct!");
                    end   
            endcase
        end
        else begin
            $display("error");
        end
        
    end

    $fclose(file);
    $finish;
end

always #5 clk = ~clk;

always @(posedge clk) begin
    r_answer <= answer;
end

IEEE754_Standard_Unit ISU0(
    .clk            (clk        ),
    .resetn         (resetn     ),
    .i_calc_flag    (calc_flag  ),
    .i_operand_A    (operand_A  ),
    .i_operand_B    (operand_B  ),
    .i_operator     (operator   ),
    .o_exception    (exception  ),
    .o_valid        (valid      ),
    .o_result       (result     )
);

endmodule
