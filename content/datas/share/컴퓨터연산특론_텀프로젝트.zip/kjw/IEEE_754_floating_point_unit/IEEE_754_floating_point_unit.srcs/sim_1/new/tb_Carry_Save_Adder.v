`timescale 1ns / 1ps

module tb_Carry_Save_Adder();

reg                 clk     ;
reg                 resetn  ;
reg     [23 :   0]  A       ;
reg     [23 :   0]  B       ;
wire    [47 :   0]  answer  ;
wire    [47 :   0]  result  ;

assign  answer = A * B;

initial begin
    clk = 0;
    resetn = 0;
    #20
    resetn = 1;

    A = 24'b1001_0011_1000_0111_0011_1101;
    B = 24'b1010_1001_1100_1011_1101_1000;
    #20
    $display("A : %b", A);
    $display("B : %b", B);
    $display("answer     : %b", answer);
    $display("your result: %b", result);
    if(result == A * B) begin
        $display("correct!");
        
    end
    else begin
        $display("error!");
    end
    #20
    A = 24'b1010_1100_0111_1110_0010_1011;
    B = 24'b0101_0101_1001_0110_1110_0100;
    #20
    $display("A : %b", A);
    $display("B : %b", B);
    $display("answer     : %b", answer);
    $display("your result: %b", result);
    if(result == A * B) begin
        $display("correct!");
    end
    else begin
        $display("error!");
    end
    #20
    $finish;
end

Carry_Save_Adder CSA(
    .clk(clk)       ,
    .resetn(resetn) ,
    .i_A(A)         ,
    .i_B(B)         ,
    .o_result(result)
);

always #5 clk = ~clk;

endmodule
