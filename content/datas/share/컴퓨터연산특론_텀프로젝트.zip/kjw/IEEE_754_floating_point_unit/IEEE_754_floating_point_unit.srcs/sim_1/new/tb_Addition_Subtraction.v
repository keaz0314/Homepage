`timescale 1ns / 1ps

module tb_Addition_Subtraction();

reg                 clk         ;
reg                 resetn      ;
reg     [31 :   0]  operand_A   ;
reg     [31 :   0]  operand_B   ;
reg                 sel_addsub  ;
wire                exception   ;
wire    [31 :   0]  result      ;

initial begin
    clk = 0;
    resetn = 0;
    #20
    resetn = 1;
    operand_A = 32'b0100_0001_0000_1011_1110_0100_1000_0000;
    operand_B = 32'b0100_0010_1010_0111_1111_0111_0001_0110;
    sel_addsub = 0;
    #20
    $display("-------------------------------------------");
    $display("A = %b   = 8.743286", operand_A);
    $display("B = %b   = 83.982589", operand_B);
    if(sel_addsub == 1'b0) begin
        $display("add");
    end
    else begin
        $display("sub");
    end
    $display("answer        : 01000010101110010111001110100110   = 92.725876");
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0010_1011_1001_0111_0011_1010_0110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #20
    sel_addsub = 1;
    #20
    $display("-------------------------------------------");
    $display("A = %b   = 8.743286", operand_A);
    $display("B = %b   = 83.982589", operand_B);
    if(sel_addsub == 1'b0) begin
        $display("add");
    end
    else begin
        $display("sub");
    end
    $display("answer        : 11000010100101100111101010000110   = -75.239304");
    $display("your reseult  : %b", result);
    if(result == 32'b1100_0010_1001_0110_0111_1010_1000_0110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end    
    #20
    operand_A = 32'b1011_1111_0001_0001_1101_0010_1010_1110;
    operand_B = 32'b0100_0010_1000_0101_1101_1000_1010_0011;
    sel_addsub = 0;
    #20
    $display("-------------------------------------------");
    $display("A = %b   = -0.569621", operand_A);
    $display("B = %b   = 66.923119", operand_B);
    if(sel_addsub == 1'b0) begin
        $display("add");
    end
    else begin
        $display("sub");
    end
    $display("answer        : 01000010100001001011010011111110   = 66.353500");
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0010_1000_0100_1011_0100_1111_1110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end  
    #20
    sel_addsub = 1;
    #20
    $display("-------------------------------------------");
    $display("A = %b   = -0.569621", operand_A);
    $display("B = %b   = 66.923119", operand_B);
    if(sel_addsub == 1'b0) begin
        $display("add");
    end
    else begin
        $display("sub");
    end
    $display("answer        : 11000010100001101111110001001000   = -67.492737");
    $display("your reseult  : %b", result);
    if(result == 32'b1100_0010_1000_0110_1111_1100_0100_1000) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    
    //exception test
    operand_A = 32'b0111_1111_0111_0001_1101_0010_1010_1110;
    operand_B = 32'b0111_1111_0111_0101_1101_1000_1010_0011;
    sel_addsub = 0;
    #20
    $display("-------------------------------------------");
    $display("A = %b", operand_A);
    $display("B = %b", operand_B);
    if(sel_addsub == 1'b0) begin
        $display("add");
    end
    else begin
        $display("sub");
    end
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0010_1000_0100_1011_0100_1111_1110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end  
    #20
    operand_A = 32'b1111_1111_0111_1111_1111_1111_1111_1110;
    operand_B = 32'b0111_1111_1111_1111_1111_1000_1010_0011;
    sel_addsub = 1;
    #20
    $display("-------------------------------------------");
    $display("A = %b", operand_A);
    $display("B = %b", operand_B);
    if(sel_addsub == 1'b0) begin
        $display("add");
    end
    else begin
        $display("sub");
    end
    $display("your reseult  : %b", result);
    if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end  
    #20
    $finish;
end

always begin
    #5  clk = ~clk;
end

Addition_Subtraction AS0(
    .clk            (clk        ),
    .resetn         (resetn     ),
    .i_operand_A    (operand_A  ),
    .i_operand_B    (operand_B  ),
    .i_sel_addsub   (sel_addsub ),
    .o_exception    (exception  ),
    .o_result       (result     )
);
endmodule