`timescale 1ns / 1ps

module tb_Brent_Kung_24bits();

reg     [23 :   0]  A       ;
reg     [23 :   0]  B       ;
wire    [24 :   0]  answer  ;
wire    [24 :   0]  result  ;

assign  answer = A + B;

initial begin
    A = 24'b1111_1111_1111_1111_1111_1111;
    B = 24'b1111_1111_1111_1111_1111_1111;
    #10
    if(result == answer) begin
        $display("---------------------------------");
        $display("%d + %d", A, B);
        $display("answer        : %d", answer);
        $display("your reseult  : %d", result);
        $display("correct!");
    end
    else begin
        $display("---------------------------------");
        $display("%d + %d", A, B);
        $display("answer        : %d", answer);
        $display("your reseult  : %d", result);
        $display("error!");
    end
    #10
    A = 24'b1111_0110_1101_1011_1111_1000;
    B = 24'b1011_1110_0111_1111_1001_1111;
    #10
    if(result == answer) begin
        $display("---------------------------------");
        $display("%d + %d", A, B);
        $display("answer        : %d", answer);
        $display("your reseult  : %d", result);
        $display("correct!");
    end
    else begin
        $display("---------------------------------");
        $display("%d + %d", A, B);
        $display("answer        : %d", answer);
        $display("your reseult  : %d", result);
        $display("error!");
    end
    #10
    A = 24'b1000_1111_1111_1101_0111_1111;
    B = 24'b1111_0001_1000_0001_1100_0010;
    #10
    if(result == answer) begin
        $display("---------------------------------");
        $display("%d + %d", A, B);
        $display("answer        : %d", answer);
        $display("your reseult  : %d", result);
        $display("correct!");
    end
    else begin
        $display("---------------------------------");
        $display("%d + %d", A, B);
        $display("answer        : %d", answer);
        $display("your reseult  : %d", result);
        $display("error!");
    end
    #10
    $finish;
end

Brent_Kung_24bits BK0(
    .i_A(A),
    .i_B(B),
    .o_result(result)
);

endmodule
