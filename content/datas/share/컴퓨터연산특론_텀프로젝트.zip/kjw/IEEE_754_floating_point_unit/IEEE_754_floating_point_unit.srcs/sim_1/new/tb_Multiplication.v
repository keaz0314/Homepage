`timescale 1ns / 1ps

module tb_Multiplication(

);

reg                 clk         ;
reg                 resetn      ;
reg     [31 :   0]  operand_A   ;
reg     [31 :   0]  operand_B   ;

wire                exception   ;
wire    [31 :   0]  result      ;  

initial begin
    clk = 0;
    resetn = 1;
    #20
    resetn = 0;
    #10
    resetn = 1;
    #5
    operand_A = 32'b0100_0001_0000_1011_1110_0100_1000_0000;
    operand_B = 32'b0100_0010_1010_0111_1111_0111_0001_0110;
    #20
    $display("-------------------------------------------");
    $display("A = %b   = 8.743286", operand_A);
    $display("B = %b   = 83.982589", operand_B);

    $display("answer        : 01000100001101111001001000101010   = 734.283813");
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0100_0011_0111_1001_0010_0010_1010) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #20
    operand_A = 32'b1011_1111_0001_0001_1101_0010_1010_1110;
    operand_B = 32'b0100_0010_1000_0101_1101_1000_1010_0011;
    #20
    $display("-------------------------------------------");
    $display("A = %b   = -0.569621", operand_A);
    $display("B = %b   = 66.923119", operand_B);
    $display("answer        : 11000010000110000111101110110110   = -38.120811");
    $display("your reseult  : %b", result);
    if(result == 32'b1100_0010_0001_1000_0111_1011_1011_0110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end  
    #20
    //exception test
    operand_A = 32'b0111_1111_0111_0001_1101_0010_1010_1110;
    operand_B = 32'b0111_1111_0111_0101_1101_1000_1010_0011;
    #20
    $display("-------------------------------------------");
    $display("A = %b", operand_A);
    $display("B = %b", operand_B);
    $display("answer        : overflow");
    if(exception == 1) begin
        $display("your result : exception!");
    end
    else begin
        $display("error!");
    end  
    #20
    operand_A = 32'b1111_1111_0111_1111_1111_1111_1111_1110;
    operand_B = 32'b0111_1111_1111_1111_1111_1000_1010_0011;
    #20
    $display("-------------------------------------------");
    $display("A = %b", operand_A);
    $display("B = %b", operand_B);
    $display("answer        : NaN");
    if(exception == 1) begin
        $display("your result : exception!");
    end
    else begin
        $display("error!");
    end  
    #20
    $finish;
end

always begin
    #5 clk = ~clk;
end

Multiplication AS0(
    .clk            (clk        ),
    .resetn         (resetn     ),
    .i_operand_A    (operand_A  ),
    .i_operand_B    (operand_B  ),
    .o_exception    (exception  ),
    .o_result       (result     )
);

endmodule    

