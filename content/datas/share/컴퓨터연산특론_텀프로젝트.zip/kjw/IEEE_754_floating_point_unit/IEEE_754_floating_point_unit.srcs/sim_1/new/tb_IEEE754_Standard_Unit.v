`timescale 1ns / 1ps

module tb_IEEE754_Standard_Unit();

reg                 clk      ;
reg                 resetn   ;
reg     [31 :   0]  operand_A;
reg     [31 :   0]  operand_B;
reg     [1  :   0]  operator;
reg                 calc_flag;
wire                exception;
wire                valid;
wire    [31 :   0]  result;

initial begin
    clk = 0;
    resetn = 0;
    #10;
    resetn = 1;
    #10;    
    operand_A = 32'b0100_0010_1010_0111_1111_0111_0001_0110;
    operand_B = 32'b0100_0001_0000_1011_1110_0100_1000_0000;
    operator = 2'b00;
    calc_flag = 1'b1;
    wait (valid == 1);
    
    #10
    $display("-------------------------------------------");
    $display("A = %b   = 83.982589", operand_A);
    $display("B = %b   = 8.743286", operand_B);
    if(operator == 2'b00) begin
        $display("add");
    end
    else if(operator == 2'b01) begin
        $display("sub");
    end
    else if(operator == 2'b10) begin
        $display("mul");
    end
    else begin
        $display("x");
    end
    $display("answer        : 01000010101110010111001110100110   = 92.725876");
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0010_1011_1001_0111_0011_1010_0110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #10
    operator = 2'b01;
    calc_flag = 1'b0;
    #20
    calc_flag = 1'b1;
    wait (valid == 1);
    #10
    $display("-------------------------------------------");
    $display("A = %b   = 83.982589", operand_A);
    $display("B = %b   = 8.743286", operand_B);
    if(operator == 2'b00) begin
        $display("add");
    end
    else if(operator == 2'b01) begin
        $display("sub");
    end
    else if(operator == 2'b10) begin
        $display("mul");
    end
    else begin
        $display("x");
    end
    $display("answer        : 01000010100101100111101010000110   = 75.239304");
    $display("your reseult  : %b", result);
    if(result == 32'b01000010100101100111101010000110) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #10
    operator = 2'b10;
    calc_flag = 1'b0;
    #20
    calc_flag = 1'b1;
    wait (valid == 1);
    #10
    $display("-------------------------------------------");
    $display("A = %b   = 83.982589", operand_A);
    $display("B = %b   = 8.743286", operand_B);
    if(operator == 2'b00) begin
        $display("add");
    end
    else if(operator == 2'b01) begin
        $display("sub");
    end
    else if(operator == 2'b10) begin
        $display("mul");
    end
    else begin
        $display("x");
    end
    $display("answer        : 01000100001101111001001000101010   = 734.283813");
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0100_0011_0111_1001_0010_0010_1010) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #10
    
    operand_A = 32'b0100_0001_1111_1100_1100_1111_1011_1001;
    operand_B = 32'b1100_0010_1011_1010_1101_0011_0010_1100;
    operator = 2'b00;
    calc_flag = 1'b0;
    #20
    calc_flag = 1'b1;
    wait (valid == 1);
    #10
    $display("-------------------------------------------");
    $display("A = %b   = 31.601427", operand_A);
    $display("B = %b   = -93.412445", operand_B);
    if(operator == 2'b00) begin
        $display("add");
    end
    else if(operator == 2'b01) begin
        $display("sub");
    end
    else if(operator == 2'b10) begin
        $display("mul");
    end
    else begin
        $display("x");
    end
    $display("answer        : 11000010011101110011111001111100   = -61.811020");
    $display("your reseult  : %b", result);
    if(result == 32'b1100_0010_0111_0111_0011_1110_0111_1100) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #10
    operator = 2'b01;
    calc_flag = 1'b0;
    #20
    calc_flag = 1'b1;
    wait (valid == 1);
    #10
    $display("-------------------------------------------");
    $display("A = %b   = 31.601427", operand_A);
    $display("B = %b   = -93.412445", operand_B);
    if(operator == 2'b00) begin
        $display("add");
    end
    else if(operator == 2'b01) begin
        $display("sub");
    end
    else if(operator == 2'b10) begin
        $display("mul");
    end
    else begin
        $display("x");
    end
    $display("answer        : 01000010111110100000011100011010   = 125.013878");
    $display("your reseult  : %b", result);
    if(result == 32'b0100_0010_1111_1010_0000_0111_0001_1010) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #10
    operator = 2'b10;
    calc_flag = 1'b0;
    #20
    calc_flag = 1'b1;
    wait (valid == 1);
    #10
    $display("-------------------------------------------");
    $display("A = %b   = 31.601427", operand_A);
    $display("B = %b   = -93.412445", operand_B);
    if(operator == 2'b00) begin
        $display("add");
    end
    else if(operator == 2'b01) begin
        $display("sub");
    end
    else if(operator == 2'b10) begin
        $display("mul");
    end
    else begin
        $display("x");
    end
    $display("answer        : 11000101001110000111111101110111   = -2951.966553");
    $display("your reseult  : %b", result);
    if(result == 32'b1100_0101_0011_1000_0111_1111_0111_0111) begin
        $display("correct!");
    end
    else if(exception == 1) begin
        $display("exception!");
    end
    else begin
        $display("error!");
    end
    #10
    
    $finish;
end

always begin
    #5 clk = ~clk;
end

IEEE754_Standard_Unit ISU(
    .clk            (clk        ),
    .resetn         (resetn     ),
    .i_calc_flag    (calc_flag  ),
    .i_operand_A    (operand_A  ),
    .i_operand_B    (operand_B  ),
    .i_operator     (operator   ),
    .o_exception    (exception  ),
    .o_valid        (valid      ),
    .o_result       (result     )
);

endmodule
