
module multiply(
    input  [15:0] multiplicand,
    input  [17:0] lutup_3_multiplicand,
    input  [17:0] lutup_minus_multiplicand,
    input  [17:0] lutup_minus_3_multiplicand,
    input  [15:0] multiplier,
    output  [30:0] product,
    output carry_out
    );

    wire  [18:0] partial_products0;
    wire  [20:0] partial_products1;
    wire  [20:0] partial_products2;
    wire  [20:0] partial_products3;
    wire  [20:0] partial_products4;
    wire  [18:0] partial_products5;

    radix8_booth bth(multiplicand,lutup_3_multiplicand, lutup_minus_multiplicand, lutup_minus_3_multiplicand, multiplier,
                    partial_products0,
                    partial_products1,
                    partial_products2,
                    partial_products3,
                    partial_products4,
                    partial_products5
                    );

    wire [17:0] in_csa1a[0:2];                
    wire  [23:0] csa_sum1a;
    wire  [21:0] csa_carry1a;

    wire [17:0] in_csa1b[0:2];
    wire  [21:0] csa_sum1b;
    wire  [24:0] csa_carry1b;
                    

    assign in_csa1a[0] = {2'b00, partial_products0[18:3]};
    assign in_csa1a[1] = partial_products1[20:3];
    assign in_csa1a[2] = partial_products2[17:0];

    assign in_csa1b[0] = {3'b000, partial_products3[20:6]};
    assign in_csa1b[1] = partial_products4[20:3];
    assign in_csa1b[2] = partial_products5[17:0];

    CSA3to2 #(.N(18)) csa1a( in_csa1a[0], in_csa1a[1] , in_csa1a[2],
                            csa_sum1a[20:3], csa_carry1a[21:4]);

    assign csa_sum1a[23:21] = partial_products2[20:18];
    assign csa_sum1a[2:0] = partial_products1[2:0];
    assign csa_carry1a[3:0] = {1'b0, partial_products0[2:0]};

    
    CSA3to2 #(.N(18)) csa1b( in_csa1b[0], in_csa1b[1], in_csa1b[2],
                            csa_sum1b[20:3], csa_carry1b[24:7]);

    assign csa_sum1b[21] = partial_products5[18];
    assign csa_sum1b[2:0] = partial_products4[2:0];
    assign csa_carry1b[6:0] = {1'b0, partial_products3[5:0]};


    wire [17:0] csa_sum2;
    wire [17:0] csa_carry2;
    
    wire [17:0] in_csa2[0:2];

    assign in_csa2[0] = {2'b00, csa_carry1a[21:6]};
    assign in_csa2[1] = csa_sum1a[23:6];
    assign in_csa2[2] = csa_carry1b[17:0];

    CSA3to2 #(.N(18)) csa2( in_csa2[0], in_csa2[1] , in_csa2[2],
                            csa_sum2, csa_carry2);
    
    wire [31:0] cpap[0:1];
    assign cpap[0][8:0] = {csa_carry2[1:0], 1'b0, csa_carry1a[5:0]};
    assign cpap[1][8:0] = {csa_sum2[2:0], csa_sum1a[5:0]};

    wire [21:0] in_csa3[0:2] ;

    assign in_csa3[0] = {6'b000000, csa_carry2[17:2]};
    assign in_csa3[1] = {csa_carry1b[24:18], csa_sum2[17:3]};
    assign in_csa3[2] = csa_sum1b;
    
    wire [21:0] csa_carry3;
    wire [21:0] csa_sum3;

    CSA3to2 #(.N(22)) csa3( in_csa3[0], in_csa3[1], in_csa3[2],
                            csa_sum3, csa_carry3);
    assign cpap[0][31:9] = {csa_carry3, 1'b0};
    assign cpap[1][31:9] = {csa_sum3[21], csa_sum3};

    CLA32 cla(cpap[0], cpap[1], 1'd0, product, carry_out);

endmodule
