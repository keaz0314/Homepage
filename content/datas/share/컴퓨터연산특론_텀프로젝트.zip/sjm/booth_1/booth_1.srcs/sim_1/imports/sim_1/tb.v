`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/16 23:41:26
// Design Name: 
// Module Name: tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb(
    );
    reg [15:0] a;
    reg [17:0] a3;
    reg [17:0] am;
    reg [17:0] am3;
    reg [15:0] b;
    wire [30:0] sum;

    multiply m(a, a3, am, am3, b,sum);
    initial begin
    // positive * positive
   
    a <= 16'd14589;
    a3 <= 3*18'd14589;
    am <= -1*18'd14589;
    am3 <= -3*18'd14589;
    b <= 16'd23145;
    
    #20;
    // positive * negative
    a <= 16'd22459;
    a3 <= 3*18'd22459;
    am <= -1*18'd22459;
    am3 <= -3*18'd22459;
    b <= -1*16'd3294;
    
    #20;
    // negative * positive
    a <= -1*16'd7691;
    a3 <= -3*18'd7691;
    am <= 18'd7691;
    am3 <= 3*18'd7691;  
    b <= 16'd25498;
    
    #20;
    // negative * negative
    a <= -1*16'd12843;
    a3 <= -3*18'd12843;
    am <= 18'd12843;
    am3 <= 3*18'd12843;
    b <= -1*16'd14891;
    
    #20;

    
    $finish;
    end
    
endmodule
