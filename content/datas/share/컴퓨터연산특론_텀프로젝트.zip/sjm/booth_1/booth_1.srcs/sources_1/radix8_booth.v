module radix8_booth(
    input   signed [15:0] multiplicand,
    input   signed [17:0] lutup_3_multiplicand,
    input   signed [17:0] lutup_minus_multiplicand,
    input   signed [17:0] lutup_minus_3_multiplicand,
    input   signed [15:0] multiplier,
    output wire  [20:0] partial_products0,
    output wire  [19:0] partial_products1,
    output wire  [19:0] partial_products2,
    output wire  [19:0] partial_products3,
    output wire  [18:0] partial_products4,
    output wire  [16:0] partial_products5
);

    wire [3:0] recoded_number [0:4];
    wire [17:0] non_modified_pp [0:4];
    
    wire [1:0] recoded_number5;
    wire [15:0] non_modified_pp5;
    

    function [17:0] mux_booth1;
        input [3:0] recoded_bits;
        input [17:0] multiplicand;
        input [17:0] lutup_minus_multiplicand;
        input [17:0] lutup_3_multiplicand;
        input [17:0] lutup_minus_3_multiplicand;              
        begin
            case (recoded_bits)
                4'b0000:          mux_booth1 = 18'd0;
                4'b0001, 4'b0010: mux_booth1 = multiplicand;                       // *1
                4'b0011, 4'b0100: mux_booth1 = multiplicand <<< 1;                 // *2
                4'b0101, 4'b0110: mux_booth1 = lutup_3_multiplicand;           // *3
                4'b0111:          mux_booth1 = multiplicand <<< 2;                 // *4
                4'b1000:          mux_booth1 = lutup_minus_multiplicand <<< 2;     // *-4
                4'b1001, 4'b1010: mux_booth1 = lutup_minus_3_multiplicand;         // *-3
                4'b1011, 4'b1100: mux_booth1 = lutup_minus_multiplicand <<< 1;     // *-2
                4'b1101, 4'b1110: mux_booth1 = lutup_minus_multiplicand;           // *-1
                default:          mux_booth1 = 18'd0;
            endcase
        end
    endfunction
    
   
    assign recoded_number[0] = {multiplier[2:0],1'b0};
    assign recoded_number[1] = multiplier[5:2];
    assign recoded_number[2] = multiplier[8:5];
    assign recoded_number[3] = multiplier[11:8];
    assign recoded_number[4] = multiplier[14:11];
    assign recoded_number5 = multiplier[15:14];
    
    
    genvar i;
    generate
        for(i = 0; i < 5; i = i+1 ) begin : recoding
        assign non_modified_pp[i] = mux_booth1(recoded_number[i],
                                           multiplicand,
                                           lutup_minus_multiplicand,
                                           lutup_3_multiplicand,
                                           lutup_minus_3_multiplicand
                                           );
        end
     endgenerate
     
     assign non_modified_pp5 = ( recoded_number5 == 2'b10) ? lutup_minus_multiplicand : 
                               ( recoded_number5 == 2'b01) ? multiplicand : 15'd0;

     
    
    assign partial_products0 = {~partial_products0[17], partial_products0[17], partial_products0[17], non_modified_pp[0]};
    assign partial_products1 = {2'b11, ~non_modified_pp[1][17], non_modified_pp[1][16:0]};
    assign partial_products2 = {2'b11, ~non_modified_pp[2][17], non_modified_pp[2][16:0]};
    assign partial_products3 = {2'b11, ~non_modified_pp[3][17], non_modified_pp[3][16:0]};
    assign partial_products4 = {1'b1, ~non_modified_pp[4][17], non_modified_pp[4][16:0]};
    assign partial_products5 = {~non_modified_pp5[15], non_modified_pp5};
    

    

endmodule