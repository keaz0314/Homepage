`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/12 20:28:54
// Design Name: 
// Module Name: CLA16
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module CLA16(
    input [15:0] a,
    input [15:0] b,
    input carry_in,
    output [15:0] sum,
    output Gout,
    output Pout
    );
    
    wire [3:0] G;
    wire [3:0] P;
    wire [3:0] C;
    
    assign C[0] = carry_in;
    assign Gout = G[3];
    assign Pout = P[3];
    
    assign C[1] = G[0] | (P[0] & C[0]);
    assign C[2] = G[1] | (P[1] & G[0]) | (P[1] & P[0] & C[0]);
    assign C[3] = G[2] | (P[2] & G[1]) | (P[2] & P[1] & G[0]) | (P[2] & P[1] & P[0] & C[0]);
    
    CLA4 Group0(a[3:0],b[3:0],C[0],sum[3:0],G[0],P[0]);
    CLA4 Group1(a[7:4],b[7:4],C[1],sum[7:4],G[1],P[1]);
    CLA4 Group2(a[11:8],b[11:8],C[2],sum[11:8],G[2],P[2]);
    CLA4 Group3(a[15:12],b[15:12],C[3],sum[15:12],G[3],P[3]);
    
    




endmodule