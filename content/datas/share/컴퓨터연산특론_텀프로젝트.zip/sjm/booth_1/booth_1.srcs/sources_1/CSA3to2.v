`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/13 23:49:01
// Design Name: 
// Module Name: CSA3to2
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module CSA3to2 #(
    parameter N = 16 
)(
    input  wire [N-1:0] a, b, c,
    output wire [N-1:0] sum,
    output wire [N-1:0] carry
);

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : wallace
            assign sum[i]   = a[i] ^ b[i] ^ c[i];
            assign carry[i] = (a[i] & b[i]) | (b[i] & c[i]) | (a[i] & c[i]);
        end
    endgenerate


endmodule
