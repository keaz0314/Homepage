`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/06/17 00:16:53
// Design Name: 
// Module Name: CLA32
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module CLA32(
    input [31:0] a,
    input [31:0] b,
    input carry_in,
    output [31:0] sum,
    output carry_out
    );

    wire [1:0] G;
    wire [1:0] P;
    wire [1:0] C;
    
    assign C[0] = carry_in;
    assign carry_out = C[1];
    
    assign C[1] = G[0] | (P[0] & C[0]);
    assign C[2] = G[1] | (P[1] & G[0]) | (P[1] & P[0] & C[0]);
    
    CLA16 Group0(a[15:0],b[15:0],C[0],sum[15:0],G[0],P[0]);
    CLA16 Group1(a[31:16],b[31:16],C[1],sum[31:16],G[1],P[1]);

endmodule
