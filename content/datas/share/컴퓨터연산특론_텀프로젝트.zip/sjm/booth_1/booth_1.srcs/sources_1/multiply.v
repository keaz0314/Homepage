
module multiply(
    input  signed [15:0] multiplicand,
    input  signed [17:0] lutup_3_multiplicand,
    input  signed [17:0] lutup_minus_multiplicand,
    input  signed [17:0] lutup_minus_3_multiplicand,
    input  signed [15:0] multiplier,
    output signed [30:0] product,
    output carry_out
    );

    wire  [20:0] partial_products0;
    wire  [19:0] partial_products1;
    wire  [19:0] partial_products2;
    wire  [19:0] partial_products3;
    wire  [18:0] partial_products4;
    wire  [16:0] partial_products5;

    radix8_booth bth(multiplicand,lutup_3_multiplicand, lutup_minus_multiplicand, lutup_minus_3_multiplicand, multiplier,
                    partial_products0,
                    partial_products1,
                    partial_products2,
                    partial_products3,
                    partial_products4,
                    partial_products5
                    );

                    
    wire  [22:0] csa_sum1a;
    wire  [23:0] csa_carry1a;

    wire  [19:0] csa_sum1b;
    wire  [22:0] csa_carry1b;
                    
    wire [16:0] in_csa1a[0:2];
    wire [15:0] in_csa1b[0:2];

    assign in_csa1a[0] = {2'b00, partial_products0[20:6]};
    assign in_csa1a[1] = partial_products1[19:3];
    assign in_csa1a[2] = partial_products2[16:0];

    assign in_csa1b[0] = {2'b00, partial_products3[19:6]};
    assign in_csa1b[1] = partial_products4[18:3];
    assign in_csa1b[2] = partial_products5[15:0];

    CSA3to2 #(.N(17)) csa1a( in_csa1a[0], in_csa1a[1] , in_csa1a[2],
                            csa_sum1a[19:3], csa_carry1a[23:7]);

    assign csa_sum1a[22:20] = partial_products2[19:17];
    assign csa_sum1a[2:0] = partial_products1[2:0];
    assign csa_carry1a[6:0] = {1'b0, partial_products0[5:0]};

    
    CSA3to2 #(.N(16)) csa1b( in_csa1b[0], in_csa1b[1], in_csa1b[2],
                            csa_sum1b[18:3], csa_carry1b[22:7]);

    assign csa_sum1b[19] = partial_products5[16];
    assign csa_sum1b[2:0] = partial_products4[2:0];
    assign csa_carry1b[6:0] = {1'b0, partial_products3[5:0]};


    wire [16:0] csa_sum2;
    wire [16:0] csa_carry2;
    
    wire [16:0] in_csa2[0:2];

    assign in_csa2[0] = {2'b00, csa_carry1a[23:9]};
    assign in_csa2[1] = csa_sum1a[22:6];
    assign in_csa2[2] = csa_carry1b[16:0];

    CSA3to2 #(.N(17)) csa2( in_csa2[0], in_csa2[1] , in_csa2[2],
                            csa_sum2[16:0], csa_carry2[16:0]);
    
    wire [31:0] cpap[0:1];
    assign cpap[0][11:0] = {csa_carry2[1:0], 1'b0, csa_carry1a[8:0]};
    assign cpap[1][11:0] = {csa_sum2[2:0], csa_sum1a[5:0],3'b000};

    wire [19:0] in_csa3[0:2] ;

    assign in_csa3[0] = {5'b00000, csa_carry2[16:2]};
    assign in_csa3[1] = {csa_carry1b[22:17], csa_sum2[16:3]};
    assign in_csa3[2] = csa_sum1b;
    
    wire [19:0] csa_carry3;
    wire [19:0] csa_sum3;

    CSA3to2 #(.N(20)) csa3( in_csa3[0], in_csa3[1], in_csa3[2],
                            csa_sum3, csa_carry3);
    assign cpap[0][31:12] = {csa_carry3[18:0], 1'b0};
    assign cpap[1][31:12] = csa_sum3;
    
    CLA32 cla(cpap[0], cpap[1], 1'd0, product, carry_out);

endmodule
