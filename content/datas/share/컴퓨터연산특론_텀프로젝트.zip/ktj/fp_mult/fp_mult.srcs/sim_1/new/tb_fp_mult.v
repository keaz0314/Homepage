`timescale 1ns/1ps
`define TEST_LIST "C:/Users/PC/Desktop/ktj/fp_mult/test_list.txt"
`define TEST_RESULT "C:/Users/PC/Desktop/ktj/fp_mult/test_result.txt"

module tb_fp_mult;

    localparam              TCLK            = 20;

    localparam              LATENCY         = 7,
                            EXCEPTION_NUM   = 0,
                            DELAY           = LATENCY+EXCEPTION_NUM;

    localparam              TEST_NUM        = 10000,
                            IDX_BW          = $clog2(TEST_NUM);

    reg                     iCLK, iRESETn;
    reg     [31:0]          iA, iX;

    wire                    oINVALID;
    wire                    oOVERFLOW;
    wire                    oUNDERFLOW;
    wire                    oINEXACT;
    wire    [31:0]          oRESULT;

    // For testbench only
    reg     [31:0]          a[TEST_NUM-1:0];
    reg     [31:0]          x[TEST_NUM-1:0];
    reg     [31:0]          r[TEST_NUM-1:0];
    reg                     exc_end = 0;
    reg     [IDX_BW-1:0]    idx     = 0;
    reg     [IDX_BW-1:0]    correct = 0;
    reg     [DELAY-1:0]     valid   = {DELAY{1'b0}};
    wire                    zero    = FP_MULT.r_zero[LATENCY-2];
    wire                    inf     = FP_MULT.r_inf[LATENCY-2];
    wire    [31:0]          expected_result;
    integer                 fd_test, fd_result, code, i, j;

    fp_mult FP_MULT(
        .iCLK       (iCLK),
        .iRESETn    (iRESETn),
        .iA         (iA),
        .iX         (iX),
        .oINVALID   (oINVALID),
        .oOVERFLOW  (oOVERFLOW),
        .oUNDERFLOW (oUNDERFLOW),
        .oINEXACT   (oINEXACT),
        .oRESULT    (oRESULT));

    initial begin
        fd_test = $fopen(`TEST_LIST, "r");
        fd_result = $fopen(`TEST_RESULT, "w");
        if(!(fd_test&&fd_result)) begin
            $display("Cannot open files");
            $stop;
        end
        for(i=0; i<TEST_NUM; i=i+1) begin
            code = $fscanf(fd_test, "%h, %h, %h\n", a[i], x[i], r[i]);
            if(code!=3) begin
                $display("Read error at line %0d (got %0d fields)", i, code);
                $stop;
            end
        end
        $fclose(fd_test);
        iCLK = 0; iRESETn = 0;
        iA = 32'h0000_0000; iX = 32'h0000_0000; #(TCLK/4);
        iRESETn = 1;
        iA = 32'h7F80_0000; iX = 32'hC02D_F854; #(TCLK);    // inf * finite -> inf (negative)
        iA = 32'h7F7F_FFFF; iX = 32'h4120_0000; #(TCLK);    // Overflow -> inf (positive)
        iA = 32'h0080_0000; iX = 32'h0080_0000; #(TCLK);    // Underflow -> zero
        iA = 32'h0000_0000; iX = 32'hC049_0FDB; #(TCLK);    // Zero * anything -> zero
        iA = 32'h0A00_0000; iX = 32'h2F00_0000; #(TCLK);    // Denormalized number -> underflow
        iA = 32'h7F80_0000; iX = 32'h0000_0000; #(TCLK);    // Inf * zero -> invalid operation
        iA = 32'h7FC0_0001; iX = 32'h3F9D_F3B0; #(TCLK);    // NaN * anything -> qNaN
        iA = 32'h6E80_0000; iX = 32'h4D80_0000; #(TCLK);    // Exact result
        exc_end = 1;
        for(i=0; i<TEST_NUM; i=i+1) begin
            iA = a[i]; iX = x[i]; #(TCLK);
        end
    end

    always @ (posedge iCLK) begin
        if(exc_end) begin
            valid[0]    <= 1'b1;
            for(j=1; j<DELAY; j=j+1)
                valid[j]    <= valid[j-1];
        end
    end

    assign  expected_result = valid[DELAY-1]?r[idx]:32'b0;

    always @ (posedge iCLK) begin
        if(valid[DELAY-1]) begin
            $display("%04d. %h x %h;  Expected result: %h, Result: %h", idx, a[idx], x[idx], r[idx], oRESULT);
            if (r[idx] == oRESULT) begin
                $display("Test passed");
                $fdisplay(fd_result, "Test passed -> %04d. %h x %h;  Expected result: %h, Result: %h", idx, a[idx], x[idx], r[idx], oRESULT);
                correct = correct + 1;
            end
            else begin
                $fdisplay(fd_result, "Test failed -> %04d. %h x %h;  Expected result: %h, Result: %h", idx, a[idx], x[idx], r[idx], oRESULT);
            end
            idx = idx + 1;
            if(idx == TEST_NUM) begin
                $display("Accuracy: %0d/%0d", correct, TEST_NUM);
                $fdisplay(fd_result, "Accuracy: %0d/%0d", correct, TEST_NUM);
                $fclose(fd_result);
                $stop;
            end
        end
    end

    always #(TCLK/2) iCLK = ~iCLK;

    // initial begin
    //     iA = 32'h7F80_0000; iX = 32'hC02D_F854; #(TCLK);  // inf * finite -> inf (negative)
    //     iA = 32'h7F7F_FFFF; iX = 32'h4000_0000; #(TCLK);    // Overflow -> inf (positive)
    //     iA = 32'h0080_0000; iX = 32'h0080_0000; #(TCLK);    // Underflow -> zero
    //     iA = 32'h0000_0000; iX = 32'hC049_0FDB; #(TCLK);    // Zero * anything -> zero
    //     iA = 32'h7F80_0000; iX = 32'h0000_0000; #(TCLK);    // Inf * zero -> invalid operation
    //     iA = 32'h7FC0_0001; iX = 32'h3F9D_F3B0; #(TCLK);    // NaN * anything -> qNaN
    // end

endmodule