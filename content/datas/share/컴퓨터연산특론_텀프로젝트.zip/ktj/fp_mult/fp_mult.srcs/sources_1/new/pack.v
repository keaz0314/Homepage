module pack #(
    parameter                   BW      = 32,
                                M_BW    = 23,
                                ES_BW   = 9)(
    input   wire                iSIGN,
    input   wire    [ES_BW-1:0] iEXP,
    input   wire    [M_BW-1:0]  iFRACTION,
    input   wire                iINVALID,
    input   wire                iINEXACT,
    input   wire                iNaN,
    input   wire                iINF,
    input   wire                iZERO,
    output  wire                oINVALID,
    output  wire                oINEXACT,
    output  wire                oOVERFLOW,
    output  wire                oUNDERFLOW,
    output  wire    [BW-1:0]    oRESULT);

    wire                        invalid;
    wire                        inexact;
    wire                        nan;
    wire                        inf;
    wire                        zero;
    wire                        overflow;
    wire                        underflow;

    assign  invalid     = iINVALID;
    assign  inexact     = iINEXACT&(~|{overflow, underflow});
    assign  inf         = iINF|((&iEXP[7:0])&(~|iFRACTION));
    assign  zero        = iZERO|(~|{iEXP[7:0], iFRACTION});
    assign  nan         = iNaN|((&iEXP[7:0])&(~inf));
    // Max value is 1111_1110+1111_1110-0111_1111=1_0111_1101
    assign  overflow    = (iEXP[8]&(~iEXP[7]))&(~nan);
    // Min value is 0000_0001+0000_0001-0111_1111=1_1000_0011
    assign  underflow   = ((&iEXP[8:7])|((~|iEXP[7:0])&(|iFRACTION)))&(~(inf|zero));

    assign  oINVALID    = invalid;
    assign  oINEXACT    = inexact;
    assign  oOVERFLOW   = overflow;
    assign  oUNDERFLOW  = underflow;
    assign  oRESULT     = invalid?{iSIGN, 8'hFF, 23'h400000}:  // Canonical qNaN
                          nan?{iSIGN, 8'hFF, iFRACTION}:       // qNaN
                          zero?{iSIGN, 8'b0, 23'b0}:           // Zero
                          inf?{iSIGN, 8'hFF, 23'b0}:           // Infinity
                          underflow?{iSIGN, 8'b0, 23'b0}:      // Underflow -> zero
                          overflow?{iSIGN, 8'hFF, 23'b0}:      // Overflow -> infinity
                          {iSIGN, iEXP[7:0], iFRACTION};        // Normal value

endmodule