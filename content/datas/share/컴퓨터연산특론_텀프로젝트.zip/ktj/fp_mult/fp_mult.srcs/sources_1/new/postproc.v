module postproc #(
    parameter                   BW  = 16)(
    input   wire    [BW-1:0]    iP,
    input   wire    [BW:0]      iCIN,
    output  wire    [BW-1:0]    oSUM,
    output  wire                oCOUT);

    // assign  oSUM    = (iX^iY)^iCIN;
    assign  oSUM    = iP^iCIN;
    assign  oCOUT   = iCIN[BW];

endmodule