module unpack #(
    parameter                   BW      = 32,
                                E_BW    = 8, 
                                M_BW    = 23,
                                S_BW    = 24)(
    input   wire                iCLK,
    input   wire                iRESETn,
    input   wire    [BW-1:0]    iA,
    input   wire    [BW-1:0]    iX,

    output  wire                oINVALID,
    output  wire                oNaN,
    output  wire                oINF,
    output  wire                oZERO,
    output  wire                oSIGN_A,
    output  wire                oSIGN_X,
    output  wire    [E_BW-1:0]  oEXP_A,
    output  wire    [E_BW-1:0]  oEXP_X,
    output  wire    [S_BW-1:0]  oSIGNIFICAND_A,
    output  wire    [S_BW-1:0]  oSIGNIFICAND_X);

    // Registers for pipeline
    reg                         r_invalid;
    reg                         r_nan, r_inf, r_zero;
    reg                         r_sign_a, r_sign_x;
    reg             [E_BW-1:0]  r_exp_a, r_exp_x;
    reg             [M_BW-1:0]  r_frac_a, r_frac_x;

    wire                        invalid;
    wire                        nan, inf, zero;

    wire                        sign_a, sign_x;
    wire            [E_BW-1:0]  exp_a, exp_x;
    wire            [M_BW-1:0]  frac_a, frac_x;

    wire                        exception;

    assign  sign_a          = iA[31];
    assign  sign_x          = iX[31];
    assign  exp_a           = iA[30:23];
    assign  exp_x           = iX[30:23];
    assign  frac_a          = iA[22:0];
    assign  frac_x          = iX[22:0];

    assign  invalid         = inf&zero;
    assign  nan_a           = (&exp_a)&(|frac_a);
    assign  nan_x           = (&exp_x)&(|frac_x);
    assign  nan             = nan_a|nan_x;
    assign  inf             = ((&exp_a)&(~|frac_a))|((&exp_x)&(~|frac_x));
    assign  zero            = (~|{exp_a, frac_a})|(~|{exp_x, frac_x});

    assign  exception       = invalid|inf|zero;

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            r_invalid   <= 1'b0;
            r_nan       <= 1'b0;
            r_inf       <= 1'b0;
            r_zero      <= 1'b0;
            r_sign_a    <= 1'b0;
            r_exp_a     <= 8'b0;
            r_frac_a    <= 23'b0;
            r_sign_x    <= 1'b0;
            r_exp_x     <= 8'b0;
            r_frac_x    <= 23'b0;
        end
        else begin // If exception is 1, then output 0
            r_invalid   <= invalid;
            r_nan       <= nan;
            r_inf       <= inf;
            r_zero      <= zero;
            r_sign_a    <= sign_a;
            r_sign_x    <= sign_x;
            r_exp_a     <= exp_a&{8{~exception}};
            r_exp_x     <= exp_x&{8{~exception}};
            r_frac_a    <= frac_a&{23{~nan_a}};
            r_frac_x    <= frac_x&{23{~nan_x}};
        end
    end

    assign  oINVALID        = r_invalid;
    assign  oNaN            = r_nan;
    assign  oINF            = r_inf;
    assign  oZERO           = r_zero;
    assign  oSIGN_A         = r_sign_a;
    assign  oSIGN_X         = r_sign_x;
    assign  oEXP_A          = r_exp_a;
    assign  oEXP_X          = r_exp_x;
    assign  oSIGNIFICAND_A  = {1'b1, r_frac_a};
    assign  oSIGNIFICAND_X  = {1'b1, r_frac_x};

endmodule