module booth_multiplier #(
    parameter                           BW      = 32,
                                        S_BW    = 24,
                                        PS_BW   = 48)(
    input   wire                        iCLK,
    input   wire                        iRESETn,
    input   wire    [S_BW-1:0]          iA,
    input   wire    [S_BW-1:0]          iX,
    output  wire    [PS_BW-1:0]         oRESULT);

    localparam                          GROUP   = S_BW/2+1,     // Number of PPs
                                        PP_BW   = S_BW+1,       // Bit width of PP
                                        EXT_BW  = PS_BW-PP_BW;  // Bit width for sign extension

    reg             [PS_BW-1:0]         r_ext_pp12;             // Delay during stage 1
    reg             [PS_BW-1:0]         r_result;               // Result register for pipeline

    wire            [GROUP-1:0]         sign, signn;            // Signs of each PP
    wire            [PP_BW*GROUP-1:0]   pps;                    // 13 PPs vector
    wire            [PP_BW-1:0]         pp[GROUP-1:0];          // Split PP vector

    wire            [PS_BW-1:0]         ext_pp[GROUP-1:0];      // Sign extended PPs
    wire            [PS_BW-1:0]         stage1_s[2:0];
    wire            [PS_BW-1:0]         stage1_c[2:0];
    wire            [PS_BW-1:0]         stage2_s[1:0];
    wire            [PS_BW-1:0]         stage2_c[1:0];
    wire            [PS_BW-1:0]         stage3_s;
    wire            [PS_BW-1:0]         stage3_c;

    wire            [PS_BW-1:0]         result;

    // PP generation (radix-4 modified Booth's algorithm)
    pp_gen #(
        .BW     (S_BW),
        .GROUP  (GROUP),
        .PP_BW  (PP_BW))
    PP_GEN  (
        .iA     (iA),
        .iX     (iX),
        .oSIGN  (sign),
        .oSIGNn (signn),
        .oPPS   (pps));

    genvar i;
    generate
        for(i=0; i<GROUP; i=i+1) begin: SPLIT_PPS
            assign  pp[i]   = pps[i*PP_BW+:PP_BW];
        end
    endgenerate

    // Sign extension
    assign  ext_pp[0]   = {{EXT_BW{sign[0]}}, pp[0]};

    genvar j;
    generate
        for(j=1; j<GROUP; j=j+1) begin: EXT_PPS
            assign  ext_pp[j]   = {{EXT_BW{sign[j]}}, pp[j], 1'b0, sign[j-1], {2*(j-1){1'b0}}};
        end
    endgenerate

    // Partial products addition (3 stages)
    /************** Stage 1 **************/
    compress_stage1 #(      // 1 cycle delay
        .PS_BW      (PS_BW))
    COMPRESS_STAGE1  (
        .iCLK       (iCLK),
        .iRESETn    (iRESETn),
        .iOP_SET0   ({ext_pp[0], ext_pp[1], ext_pp[2],  ext_pp[3]}),
        .iOP_SET1   ({ext_pp[4], ext_pp[5], ext_pp[6],  ext_pp[7]}),
        .iOP_SET2   ({ext_pp[8], ext_pp[9], ext_pp[10], ext_pp[11]}),
        .oS0        (stage1_s[0]),
        .oC0        (stage1_c[0]),
        .oS1        (stage1_s[1]),
        .oC1        (stage1_c[1]),
        .oS2        (stage1_s[2]),
        .oC2        (stage1_c[2]));

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn)
            r_ext_pp12  <= {PS_BW{1'b0}};
        else
            r_ext_pp12  <= ext_pp[12];
    end

    /************** Stage 2 **************/
    compress_stage2 #(      // 1 cycle delay
        .PS_BW      (PS_BW))
    COMPRESS_STAGE2  (
        .iCLK       (iCLK),
        .iRESETn    (iRESETn),
        .iOP_SET0   ({stage1_c[0], stage1_s[0], stage1_c[1], stage1_s[1]}),
        .iOP_SET1   ({stage1_c[2], stage1_s[2], r_ext_pp12}),
        .oS0        (stage2_s[0]),
        .oC0        (stage2_c[0]),
        .oS1        (stage2_s[1]),
        .oC1        (stage2_c[1]));

    /************** Stage 3 **************/
    compress_stage3 #(      // 1 cycle delay
        .PS_BW      (PS_BW))
    COMPRESS_STAGE3  (
        .iCLK       (iCLK),
        .iRESETn    (iRESETn),
        .iOP_SET    ({stage2_c[0], stage2_s[0], stage2_c[1], stage2_s[1]}),
        .oS         (stage3_s),
        .oC         (stage3_c));

    /**************** CPA ****************/
    bka_48bit #(
        .BW         (PS_BW))
    BKA_48BIT  (
        .iX         (stage3_s),
        .iY         (stage3_c),
        .iCIN       (1'b0),
        .oRESULT    (result),
        .oCOUT      (),
        .oBORROW    ());

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn)
            r_result    <= {PS_BW{1'b0}};
        else
            r_result    <= result;
    end

    assign  oRESULT = r_result;

endmodule