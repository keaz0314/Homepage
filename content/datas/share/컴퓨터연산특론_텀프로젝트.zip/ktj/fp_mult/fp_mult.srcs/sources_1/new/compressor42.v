module compressor42 #(
    parameter                   PS_BW   = 48)(
    input   wire    [PS_BW-1:0] iX,
    input   wire    [PS_BW-1:0] iY,
    input   wire    [PS_BW-1:0] iW,
    input   wire    [PS_BW-1:0] iZ,
    input   wire                iCIN,
    output  wire    [PS_BW-1:0] oS,
    output  wire    [PS_BW-1:0] oC,
    output  wire                oCOUT);

    wire            [PS_BW:0]   exter_c;
    wire            [PS_BW:0]   inter_c;

    assign  exter_c[0]  = 1'b0; // 1 bit shift
    assign  inter_c[0]  = iCIN;

    genvar i;
    generate
        for(i=0; i<PS_BW; i=i+1) begin: COMPRESSOR
            compressor COMPRESSOR (
                .iX     (iX[i]),
                .iY     (iY[i]),
                .iW     (iW[i]),
                .iZ     (iZ[i]),
                .iCIN   (inter_c[i]),
                .oS     (oS[i]),
                .oC     (inter_c[i+1]),
                .oCOUT  (exter_c[i+1]));
        end
    endgenerate

    assign  oC      = exter_c[PS_BW-1:0];
    assign  oCOUT   = exter_c[PS_BW];

endmodule