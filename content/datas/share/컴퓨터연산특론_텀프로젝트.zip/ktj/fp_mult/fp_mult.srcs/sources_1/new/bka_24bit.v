module bka_24bit #(
    parameter                   BW  = 24)(      // Bit width
    input   wire    [BW-1:0]    iX, iY,         // Operand 1, 2
    input   wire                iCIN,           // If 1, subtraction
    output  wire    [BW-1:0]    oRESULT,        // Operation result
    output  wire                oCOUT,          // Carry-out
    output  wire                oBORROW);       // Borrow

    // PC: propageted carry, GC: generated carry
    wire            [BW-1:0]    p, g;           // PC and GC for 1 bit of iX and iY
    wire            [10:0]      p0;             // PC in level 0
    wire            [11:0]      g0;             // GC in level 0
    wire            [4:0]       p1;             // PC in level 1
    wire            [5:0]       g1;             // GC in level 1
    wire            [1:0]       p2;             // PC in level 2
    wire            [2:0]       g2;             // GC in level 2
    wire                        g3;             // GC in level 3
    wire            [2:0]       g4;             // GC in level 4
    wire            [4:0]       g5;             // GC in level 5
    wire            [10:0]      g6;             // GC in level 6

    wire            [BW-1:0]    postproc_cin;   // GCs

    // Preprocessing module: Generate PC and GC for 1bit of iX and iY
    preproc #(.BW(BW))
    PREPROC  (.iX(iX), .iY(iY), .iCIN(iCIN), .oP(p), .oG(g));

    // Total stage = 2*ceil(log2(BW))-1; Black: Generate PC and GC, Gray: Generate GC only
    // Level 0
    gray  GRAY00  (.iG0(g[0]),  .iP1(p[1]),   .iG1(g[1]),   .oG(g0[0]));
    black BLACK01 (.iP0(p[2]),  .iG0(g[2]),   .iP1(p[3]),   .iG1(g[3]),   .oP(p0[0]),  .oG(g0[1]));
    black BLACK02 (.iP0(p[4]),  .iG0(g[4]),   .iP1(p[5]),   .iG1(g[5]),   .oP(p0[1]),  .oG(g0[2]));
    black BLACK03 (.iP0(p[6]),  .iG0(g[6]),   .iP1(p[7]),   .iG1(g[7]),   .oP(p0[2]),  .oG(g0[3]));
    black BLACK04 (.iP0(p[8]),  .iG0(g[8]),   .iP1(p[9]),   .iG1(g[9]),   .oP(p0[3]),  .oG(g0[4]));
    black BLACK05 (.iP0(p[10]), .iG0(g[10]),  .iP1(p[11]),  .iG1(g[11]),  .oP(p0[4]),  .oG(g0[5]));
    black BLACK06 (.iP0(p[12]), .iG0(g[12]),  .iP1(p[13]),  .iG1(g[13]),  .oP(p0[5]),  .oG(g0[6]));
    black BLACK07 (.iP0(p[14]), .iG0(g[14]),  .iP1(p[15]),  .iG1(g[15]),  .oP(p0[6]),  .oG(g0[7]));
    black BLACK08 (.iP0(p[16]), .iG0(g[16]),  .iP1(p[17]),  .iG1(g[17]),  .oP(p0[7]),  .oG(g0[8]));
    black BLACK09 (.iP0(p[18]), .iG0(g[18]),  .iP1(p[19]),  .iG1(g[19]),  .oP(p0[8]),  .oG(g0[9]));
    black BLACK0A (.iP0(p[20]), .iG0(g[20]),  .iP1(p[21]),  .iG1(g[21]),  .oP(p0[9]),  .oG(g0[10]));
    black BLACK0B (.iP0(p[22]), .iG0(g[22]),  .iP1(p[23]),  .iG1(g[23]),  .oP(p0[10]), .oG(g0[11]));

    // Level 1
    gray  GRAY10  (.iG0(g0[0]), .iP1(p0[0]),  .iG1(g0[1]),  .oG(g1[0]));
    black BLACK10 (.iP0(p0[1]), .iG0(g0[2]),  .iP1(p0[2]),  .iG1(g0[3]),  .oP(p1[0]),  .oG(g1[1]));
    black BLACK11 (.iP0(p0[3]), .iG0(g0[4]),  .iP1(p0[4]),  .iG1(g0[5]),  .oP(p1[1]),  .oG(g1[2]));
    black BLACK12 (.iP0(p0[5]), .iG0(g0[6]),  .iP1(p0[6]),  .iG1(g0[7]),  .oP(p1[2]),  .oG(g1[3]));
    black BLACK13 (.iP0(p0[7]), .iG0(g0[8]),  .iP1(p0[8]),  .iG1(g0[9]),  .oP(p1[3]),  .oG(g1[4]));
    black BLACK14 (.iP0(p0[9]), .iG0(g0[10]), .iP1(p0[10]), .iG1(g0[11]), .oP(p1[4]),  .oG(g1[5]));

    // Level 2
    gray  GRAY20  (.iG0(g1[0]), .iP1(p1[0]),  .iG1(g1[1]),  .oG(g2[0]));
    black BLACK20 (.iP0(p1[1]), .iG0(g1[2]),  .iP1(p1[2]),  .iG1(g1[3]),  .oP(p2[0]),  .oG(g2[1]));
    black BLACK21 (.iP0(p1[3]), .iG0(g1[4]),  .iP1(p1[4]),  .iG1(g1[5]),  .oP(p2[1]),  .oG(g2[2]));

    // Level 3
    gray  GRAY30  (.iG0(g2[0]), .iP1(p2[0]),  .iG1(g2[1]),  .oG(g3));

    // Level 4
    gray  GRAY40  (.iG0(g2[0]), .iP1(p1[1]),  .iG1(g1[2]),  .oG(g4[0]));
    gray  GRAY41  (.iG0(g3),    .iP1(p1[3]),  .iG1(g1[4]),  .oG(g4[1]));
    gray  GRAY42  (.iG0(g3),    .iP1(p2[1]),  .iG1(g2[2]),  .oG(g4[2]));

    // Level 5
    gray  GRAY50  (.iG0(g1[0]), .iP1(p0[1]),  .iG1(g0[2]),  .oG(g5[0]));
    gray  GRAY51  (.iG0(g2[0]), .iP1(p0[3]),  .iG1(g0[4]),  .oG(g5[1]));
    gray  GRAY52  (.iG0(g4[0]), .iP1(p0[5]),  .iG1(g0[6]),  .oG(g5[2]));
    gray  GRAY53  (.iG0(g3),    .iP1(p0[7]),  .iG1(g0[8]),  .oG(g5[3]));
    gray  GRAY54  (.iG0(g4[1]), .iP1(p0[9]),  .iG1(g0[10]), .oG(g5[4]));

    // Level 6
    gray  GRAY60  (.iG0(g0[0]), .iP1(p[2]),   .iG1(g[2]),   .oG(g6[0]));
    gray  GRAY61  (.iG0(g1[0]), .iP1(p[4]),   .iG1(g[4]),   .oG(g6[1]));
    gray  GRAY62  (.iG0(g5[0]), .iP1(p[6]),   .iG1(g[6]),   .oG(g6[2]));
    gray  GRAY63  (.iG0(g2[0]), .iP1(p[8]),   .iG1(g[8]),   .oG(g6[3]));
    gray  GRAY64  (.iG0(g5[1]), .iP1(p[10]),  .iG1(g[10]),  .oG(g6[4]));
    gray  GRAY65  (.iG0(g4[0]), .iP1(p[12]),  .iG1(g[12]),  .oG(g6[5]));
    gray  GRAY66  (.iG0(g5[2]), .iP1(p[14]),  .iG1(g[14]),  .oG(g6[6]));
    gray  GRAY67  (.iG0(g3),    .iP1(p[16]),  .iG1(g[16]),  .oG(g6[7]));
    gray  GRAY68  (.iG0(g5[3]), .iP1(p[18]),  .iG1(g[18]),  .oG(g6[8]));
    gray  GRAY69  (.iG0(g4[1]), .iP1(p[20]),  .iG1(g[20]),  .oG(g6[9]));
    gray  GRAY6A  (.iG0(g5[4]), .iP1(p[22]),  .iG1(g[22]),  .oG(g6[10]));

    // Postprocessing module: Generate sum and carry-out
    postproc #(.BW(BW))
    POSTPROC  (.iP(p), .iCIN({postproc_cin, iCIN}), .oSUM(oRESULT), .oCOUT(oCOUT));

    assign  postproc_cin    = {g4[2], g6[10], g5[4], g6[9], g4[1], g6[8],
                               g5[3], g6[7],  g3,    g6[6], g5[2], g6[5],
                               g4[0], g6[4],  g5[1], g6[3], g2[0], g6[2],
                               g5[0], g6[1],  g1[0], g6[0], g0[0], g[0]};

    assign  oBORROW         = ~oCOUT&iCIN;

endmodule