module bka_9bit #(
    parameter                   BW = 9)(        // Bit width
    input   wire    [BW-1:0]    iX, iY,         // Operand 1, 2
    input   wire                iCIN,           // If 1, subtraction
    output  wire    [BW-1:0]    oRESULT,        // Operation result
    output  wire                oCOUT);         // Carry-out

    // PC: propageted carry, GC: generated carry
    wire            [BW-1:0]    p, g;           // PC and GC for 1 bit of iX and iY
    wire            [2:0]       p0;             // PC in level 0
    wire            [3:0]       g0;             // GC in level 0
    wire                        p1;             // PC in level 1
    wire            [1:0]       g1;             // GC in level 1
    wire            [1:0]       g2;             // GC in level 2
    wire            [3:0]       g3;             // GC in level 3

    wire            [BW-1:0]    postproc_cin;   // GCs

    // Preprocessing module: Generate PC and GC for 1bit of iX and iY
    preproc #(.BW(BW))
    PREPROC  (.iX(iX), .iY(iY), .iCIN(iCIN), .oP(p), .oG(g));

    // Total stage = 2*ceil(log2(BW))-1; Black: Generate PC and GC, Gray: Generate GC only
    // Level 0
    gray  GRAY00   (.iG0(g[0]),  .iP1(p[1]),  .iG1(g[1]),  .oG(g0[0]));
    black BLACK01  (.iP0(p[2]),  .iG0(g[2]),  .iP1(p[3]),  .iG1(g[3]),  .oP(p0[0]), .oG(g0[1]));
    black BLACK02  (.iP0(p[4]),  .iG0(g[4]),  .iP1(p[5]),  .iG1(g[5]),  .oP(p0[1]), .oG(g0[2]));
    black BLACK03  (.iP0(p[6]),  .iG0(g[6]),  .iP1(p[7]),  .iG1(g[7]),  .oP(p0[2]), .oG(g0[3]));

    // Level 1
    gray  GRAY10   (.iG0(g0[0]), .iP1(p0[0]), .iG1(g0[1]), .oG(g1[0]));
    black BLACK11  (.iP0(p0[1]), .iG0(g0[2]), .iP1(p0[2]), .iG1(g0[3]), .oP(p1), .oG(g1[1]));

    // Level 2
    gray  GRAY20   (.iG0(g1[0]), .iP1(p0[1]), .iG1(g0[2]), .oG(g2[0]));
    gray  GRAY21   (.iG0(g1[0]), .iP1(p1),    .iG1(g1[1]), .oG(g2[1]));

    // Level 3
    gray  GRAY30   (.iG0(g0[0]), .iP1(p[2]),  .iG1(g[2]),  .oG(g3[0]));
    gray  GRAY31   (.iG0(g1[0]), .iP1(p[4]),  .iG1(g[4]),  .oG(g3[1]));
    gray  GRAY32   (.iG0(g2[0]), .iP1(p[6]),  .iG1(g[6]),  .oG(g3[2]));
    gray  GRAY33   (.iG0(g2[1]), .iP1(p[8]),  .iG1(g[8]),  .oG(g3[3]));

    // Postprocessing module: Generate sum and carry-out
    postproc #(.BW(BW))
    POSTPROC  (.iP(p), .iCIN({postproc_cin, iCIN}), .oSUM(oRESULT), .oCOUT(oCOUT));

    assign  postproc_cin    = {g3[3], g2[1], g3[2], g2[0], g3[1],
                               g1[0], g3[0], g0[0], g[0]};

endmodule