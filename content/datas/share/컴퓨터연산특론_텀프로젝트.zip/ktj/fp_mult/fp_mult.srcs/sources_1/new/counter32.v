module counter32 #(
    parameter                   PS_BW = 48)(
    input   wire    [PS_BW-1:0] iX,
    input   wire    [PS_BW-1:0] iY,
    input   wire    [PS_BW-1:0] iW,
    output  wire    [PS_BW-1:0] oS,     // Output
    output  wire    [PS_BW-1:0] oC,     // Output
    output  wire                oCOUT); // Next weight

    wire            [PS_BW:0]   tmp_c;

    assign  tmp_c[0]    = 1'b0;

    genvar i;
    generate
        for(i=0; i<PS_BW; i=i+1) begin: FA
            fa FA (
                .iX     (iX[i]),
                .iY     (iY[i]),
                .iCIN   (iW[i]),
                .oSUM   (oS[i]),
                .oCOUT  (tmp_c[i+1]));
        end
    endgenerate

    assign  oC      = tmp_c[PS_BW-1:0];
    assign  oCOUT   = tmp_c[PS_BW];

endmodule