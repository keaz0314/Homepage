module pp_gen#(
    parameter                           BW      = 24,
                                        GROUP   = 13,
                                        PP_BW   = 25)(
    input   wire    [BW-1:0]            iA,
    input   wire    [BW-1:0]            iX,
    output  wire    [GROUP-1:0]         oSIGN, oSIGNn,
    output  wire    [PP_BW*GROUP-1:0]   oPPS);

    wire            [GROUP-1:0]         sign, signn;
    wire            [GROUP-1:0]         magn0, magn1;   // Magnitude of recoded number (1x, 2x)
    wire            [PP_BW-1:0]         pp[GROUP-1:0];  // PPs

    // Generate recode information
    booth_recoder BOOTH_RECODER_1ST (
        .iX0    (1'b0),
        .iX1    (iX[0]),
        .iX2    (iX[1]),
        .oSIGN  (sign[0]),
        .oSIGNn (signn[0]),
        .oMAGN0 (magn0[0]),
        .oMAGN1 (magn1[0]));

    genvar i;
    generate
        for(i=1; i<GROUP-1; i=i+1) begin: BOOTH_RECODER
            booth_recoder BOOTH_RECODER (
                .iX0    (iX[i*2-1]),
                .iX1    (iX[i*2]),
                .iX2    (iX[i*2+1]),
                .oSIGN  (sign[i]),
                .oSIGNn (signn[i]),
                .oMAGN0 (magn0[i]),
                .oMAGN1 (magn1[i]));
        end
    endgenerate

    // For unsigned number (Add sign bit, and for even digits)
    booth_recoder BOOTH_RECODER_LAST (
        .iX0    (iX[BW-1]),
        .iX1    (1'b0),
        .iX2    (1'b0),
        .oSIGN  (sign[GROUP-1]),
        .oSIGNn (signn[GROUP-1]),
        .oMAGN0 (magn0[GROUP-1]),
        .oMAGN1 (magn1[GROUP-1]));

    // Generate PPs
    genvar j;
    generate
        for(j=0; j<GROUP; j=j+1) begin: BOOTH_PP_GEN
            assign  oPPS[j*PP_BW+:PP_BW]    = pp[j];
            booth_pp_gen BOOTH_PP_GEN (
                .iA     (iA),
                .iMAGN0 (magn0[j]),
                .iMAGN1 (magn1[j]),
                .iSIGN  (sign[j]),
                .oPP    (pp[j]));
        end
    endgenerate

    assign  oSIGN   = sign;
    assign  oSIGNn  = signn;

endmodule