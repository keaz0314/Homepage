module normalization #(
    parameter                   ES_BW   = 9,
                                PS_BW   = 48)(
    input   wire                iCLK,
    input   wire                iRESETn,
    input   wire    [ES_BW-1:0] iEXP,
    input   wire    [PS_BW-1:0] iPRODUCT,
    output  wire    [ES_BW-1:0] oEXP,
    output  wire    [PS_BW-1:0] oPRODUCT);

    reg             [ES_BW-1:0] r_exp;
    reg             [PS_BW-1:0] r_product;

    wire            [ES_BW-1:0] exp;
    wire            [PS_BW-1:0] product;

    wire                        norm;   // If 1, normalization required

    assign  norm    = iPRODUCT[47];

    bka_9bit #(.BW(ES_BW))
    BKA_9BIT  (.iX(iEXP), .iY(9'b0), .iCIN(norm), .oRESULT(exp), .oCOUT());

    assign  product    = norm?iPRODUCT>>1:iPRODUCT;

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            r_exp      <= {ES_BW{1'b0}};
            r_product  <= {PS_BW{1'b0}};
        end
        else begin
            r_exp      <= exp;
            r_product  <= product;
        end
    end

    assign  oEXP       = r_exp;
    assign  oPRODUCT   = r_product;

endmodule