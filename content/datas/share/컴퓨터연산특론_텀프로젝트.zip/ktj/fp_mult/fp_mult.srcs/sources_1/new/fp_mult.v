module fp_mult #(
    parameter                   BW = 32)(
    input   wire                iCLK,
    input   wire                iRESETn,
    input   wire    [BW-1:0]    iA, // Multiplicand
    input   wire    [BW-1:0]    iX, // Multiplier

    output  wire                oINVALID,
    output  wire                oOVERFLOW,
    output  wire                oUNDERFLOW,
    output  wire                oINEXACT,
    output  wire    [BW-1:0]    oRESULT);

    localparam                  LATENCY = 7,            // Total latency (7 cycles)
                                T_DELAY = LATENCY-1,    // Exclude unpack delay
                                M_DELAY = T_DELAY-2;    // Multiplication delay

    localparam                  E_BW    = 8,            // Bit width of exponent
                                M_BW    = 23,           // Bit width of fraction (mantissa)
                                S_BW    = 24,           // Bit width of significand
                                ES_BW   = 9,            // Bit width of exponent sum
                                PS_BW   = 48;           // Bit width of significand multiplication result

    // FP number's components
    wire                        sign_a, sign_x;
    wire            [E_BW-1:0]  exp_a, exp_x;
    wire            [S_BW-1:0]  significand_a, significand_x;

    // Exception flags
    wire                        invalid;
    wire                        nan, inf, zero;
    wire                        inexact;

    // Temporal multiplication results
    wire                        mult_sign;
    wire            [ES_BW-1:0] sum_exp_tmp;    // exp_a + exp_x
    wire            [ES_BW-1:0] sum_exp;        // MSB inversion
    wire            [PS_BW-1:0] product;

    // Normalized
    wire            [ES_BW-1:0] norm_exp;
    wire            [PS_BW-1:0] norm_product;

    // Rounded
    wire            [ES_BW-1:0] round_exp;
    wire            [M_BW-1:0]  round_fraction;

    // Shift registers for delay
    reg                         r_invalid[T_DELAY-1:0];
    reg                         r_nan[T_DELAY-1:0];
    reg                         r_inf[T_DELAY-1:0];
    reg                         r_zero[T_DELAY-1:0];
    reg                         r_mult_sign[T_DELAY-1:0];
    reg             [ES_BW-1:0] r_sum_exp[M_DELAY-1:0];

    integer                     i; // For `for` loop

    // Modules instantiation
    unpack #(           // Unpacking; 1 cycle delay
        .BW             (BW),
        .E_BW           (E_BW),
        .M_BW           (M_BW),
        .S_BW           (S_BW))
    UNPACK  (
        .iCLK           (iCLK),
        .iRESETn        (iRESETn),
        .iA             (iA),
        .iX             (iX),
        .oINVALID       (invalid),
        .oNaN           (nan),
        .oINF           (inf),
        .oZERO          (zero),
        .oSIGN_A        (sign_a),
        .oSIGN_X        (sign_x),
        .oEXP_A         (exp_a),
        .oEXP_X         (exp_x),
        .oSIGNIFICAND_A (significand_a),
        .oSIGNIFICAND_X (significand_x));

    booth_multiplier #( // Perform multiplication; 4 cycle delay
        .BW             (BW),
        .S_BW           (S_BW),
        .PS_BW          (PS_BW))
    BOOTH_MULTIPLIER  (
        .iCLK           (iCLK),
        .iRESETn        (iRESETn),
        .iA             (significand_a),
        .iX             (significand_x),
        .oRESULT        (product));

    normalization #(    // Postnormalization; 1 cycle delay
        .ES_BW          (ES_BW),
        .PS_BW          (PS_BW))
    NORMALIZATION (
        .iCLK           (iCLK),
        .iRESETn        (iRESETn),
        .iEXP           (r_sum_exp[M_DELAY-1]),
        .iPRODUCT       (product),
        .oEXP           (norm_exp),
        .oPRODUCT       (norm_product));

    rounding #(         // Round-to-nearest-even; 1 cycle delay
        .M_BW           (M_BW),
        .S_BW           (S_BW),
        .ES_BW          (ES_BW),
        .PS_BW          (PS_BW))
    ROUNDING (
        .iCLK           (iCLK),
        .iRESETn        (iRESETn),
        .iEXP           (norm_exp),
        .iPRODUCT       (norm_product),
        .oINEXACT       (inexact),
        .oEXP           (round_exp),
        .oFRACTION      (round_fraction));

    pack #(             // Packing; No delay
        .BW             (BW),
        .M_BW           (M_BW),
        .ES_BW          (ES_BW))
    PACK  (
        .iSIGN          (r_mult_sign[T_DELAY-1]),
        .iEXP           (round_exp),
        .iFRACTION      (round_fraction),
        .iINVALID       (r_invalid[T_DELAY-1]),
        .iINEXACT       (inexact),
        .iNaN           (r_nan[T_DELAY-1]),
        .iINF           (r_inf[T_DELAY-1]),
        .iZERO          (r_zero[T_DELAY-1]),
        .oINVALID       (oINVALID),
        .oINEXACT       (oINEXACT),
        .oOVERFLOW      (oOVERFLOW),
        .oUNDERFLOW     (oUNDERFLOW),
        .oRESULT        (oRESULT));

    // Sign bit of result
    assign  mult_sign   = sign_a^sign_x;

    // Exponent addition
    // exp_a + exp_x + 1 - 128
    assign  exp_add     = (|exp_a)&(|exp_x);
    bka_9bit #(         // exp_a + exp_b + 1
        .BW             (ES_BW))
    BKA_9BIT (
        .iX             ({1'b0, exp_a}),
        .iY             ({1'b0, exp_x}),
        .iCIN           (exp_add),
        .oRESULT        (sum_exp_tmp),
        .oCOUT          ());

    assign  sum_exp = {~^sum_exp_tmp[8:7], ~sum_exp_tmp[7], sum_exp_tmp[6:0]}&{9{exp_add}}; // - 128

    // Delay to latency
    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            for(i=0; i<T_DELAY; i=i+1) begin
                r_invalid[i]    <= 1'b0;
                r_nan[i]        <= 1'b0;
                r_inf[i]        <= 1'b0;
                r_zero[i]       <= 1'b0;
            end
        end
        else begin
            r_invalid[0]    <= invalid;
            r_nan[0]        <= nan;
            r_inf[0]        <= inf;
            r_zero[0]       <= zero;
            for(i=1; i<T_DELAY; i=i+1) begin
                r_invalid[i]    <= r_invalid[i-1];
                r_nan[i]        <= r_nan[i-1];
                r_inf[i]        <= r_inf[i-1];
                r_zero[i]       <= r_zero[i-1];
            end
        end
    end

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            for(i=0; i<T_DELAY; i=i+1) begin
                r_mult_sign[i]  <= 1'b0;
            end
        end
        else begin
            r_mult_sign[0]  <= mult_sign;
            for(i=1; i<T_DELAY; i=i+1) begin
                r_mult_sign[i]  <= r_mult_sign[i-1];
            end
        end
    end

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            for(i=0; i<M_DELAY; i=i+1) begin
                r_sum_exp[i]    <= 9'b0;
            end
        end
        else begin
            r_sum_exp[0]   <= sum_exp;
            for(i=1; i<M_DELAY; i=i+1) begin
                r_sum_exp[i]    <= r_sum_exp[i-1];
            end
        end
    end

endmodule