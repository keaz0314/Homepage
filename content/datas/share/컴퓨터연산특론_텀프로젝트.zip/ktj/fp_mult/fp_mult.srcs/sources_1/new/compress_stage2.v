module compress_stage2 #(
    parameter                       PS_BW   = 48)(
    input   wire                    iCLK,
    input   wire                    iRESETn,
    input   wire    [4*PS_BW-1:0]   iOP_SET0,
    input   wire    [3*PS_BW-1:0]   iOP_SET1,
    output  wire    [PS_BW-1:0]     oS0, oC0,
    output  wire    [PS_BW-1:0]     oS1, oC1);

    reg             [PS_BW-1:0]     r_s0, r_c0;
    reg             [PS_BW-1:0]     r_s1, r_c1;

    wire            [PS_BW-1:0]     s0, c0;
    wire            [PS_BW-1:0]     s1, c1;

    wire            [PS_BW-1:0]     x0, y0, w0, z0;
    wire            [PS_BW-1:0]     x1, y1, w1;

    assign  x0  = iOP_SET0[3*PS_BW+:PS_BW];
    assign  y0  = iOP_SET0[2*PS_BW+:PS_BW];
    assign  w0  = iOP_SET0[1*PS_BW+:PS_BW];
    assign  z0  = iOP_SET0[0*PS_BW+:PS_BW];

    assign  x1  = iOP_SET1[2*PS_BW+:PS_BW];
    assign  y1  = iOP_SET1[1*PS_BW+:PS_BW];
    assign  w1  = iOP_SET1[0*PS_BW+:PS_BW];

    compressor42 #(
        .PS_BW      (PS_BW))
    COMPRESSOR0   (
        .iX         (x0),
        .iY         (y0),
        .iW         (w0),
        .iZ         (z0),
        .iCIN       (1'b0),
        .oS         (s0),
        .oC         (c0),
        .oCOUT      ());

    counter32  #(
        .PS_BW   (PS_BW))
    COUNTER0    (
        .iX     (x1),
        .iY     (y1),
        .iW     (w1),
        .oS     (s1),
        .oC     (c1),
        .oCOUT  ());


    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            r_s0    <= {PS_BW{1'b0}};
            r_c0    <= {PS_BW{1'b0}};
            r_s1    <= {PS_BW{1'b0}};
            r_c1    <= {PS_BW{1'b0}};
        end
        else begin
            r_s0    <= s0;
            r_c0    <= c0;
            r_s1    <= s1;
            r_c1    <= c1;
        end
    end

    assign  oS0 = r_s0;
    assign  oC0 = r_c0;
    assign  oS1 = r_s1;
    assign  oC1 = r_c1;

endmodule