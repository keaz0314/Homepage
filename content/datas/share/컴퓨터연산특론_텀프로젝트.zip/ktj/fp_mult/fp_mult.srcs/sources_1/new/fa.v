module fa(
    input   wire    iX,     // Operand 1
    input   wire    iY,     // Operand 2
    input   wire    iCIN,   // Carry-in
    output  wire    oSUM,   // Sum
    output  wire    oCOUT); // Carry-out

    wire            s0, c0, c1;

    assign  s0      = iX^iY;
    assign  c0      = iX&iY;
    assign  c1      = s0&iCIN;
    assign  oSUM    = s0^iCIN;
    assign  oCOUT   = c0|c1;

endmodule