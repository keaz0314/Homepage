module bka_48bit #(
    parameter                   BW = 48)(       // Bit width
    input   wire    [BW-1:0]    iX, iY,         // Operand 1, 2
    input   wire                iCIN,           // If 1, subtraction
    output  wire    [BW-1:0]    oRESULT,        // Operation result
    output  wire                oCOUT,          // Carry-out
    output  wire                oBORROW);       // Borrow

    wire            [BW-1:0]    y_2comp;        // 2's complement of iY

    // PC: propageted carry, GC: generated carry
    wire            [BW-1:0]    p, g;           // PC and GC for 1 bit of iX and iY
    wire            [22:0]      p0;             // PC in level 0
    wire            [23:0]      g0;             // GC in level 0
    wire            [11:0]      p1;             // PC in level 1
    wire            [12:0]      g1;             // GC in level 1
    wire            [4:0]       p2;             // PC in level 2
    wire            [5:0]       g2;             // GC in level 2
    wire            [1:0]       p3;             // PG in level 3
    wire            [2:0]       g3;             // GC in level 3
    wire                        g4;             // GC in level 4
    wire            [2:0]       g5;             // GC in level 5
    wire            [4:0]       g6;             // GC in level 6
    wire            [10:0]      g7;             // GC in level 7
    wire            [22:0]      g8;             // GC in level 8

    wire            [BW-1:0]    postproc_cin;   // GCs

    assign  y_2comp     = iY^{BW{iCIN}};        // Convert to 1's complement if iCIN is 1

    // Preprocessing module: Generate PC and GC for 1bit of iX and iY
    preproc #(.BW(BW))
    PREPROC  (.iX(iX), .iY(y_2comp), .iCIN(iCIN), .oP(p), .oG(g));

    // Total stage = 2*ceil(log2(BW))-1; Black: Generate PC and GC, Gray: Generate GC only
    // Level 0
    gray  GRAY00   (.iG0(g[0]),   .iP1(p[1]),   .iG1(g[1]),   .oG(g0[0]));
    black BLACK01  (.iP0(p[2]),   .iG0(g[2]),   .iP1(p[3]),   .iG1(g[3]),   .oP(p0[0]),  .oG(g0[1]));
    black BLACK02  (.iP0(p[4]),   .iG0(g[4]),   .iP1(p[5]),   .iG1(g[5]),   .oP(p0[1]),  .oG(g0[2]));
    black BLACK03  (.iP0(p[6]),   .iG0(g[6]),   .iP1(p[7]),   .iG1(g[7]),   .oP(p0[2]),  .oG(g0[3]));
    black BLACK04  (.iP0(p[8]),   .iG0(g[8]),   .iP1(p[9]),   .iG1(g[9]),   .oP(p0[3]),  .oG(g0[4]));
    black BLACK05  (.iP0(p[10]),  .iG0(g[10]),  .iP1(p[11]),  .iG1(g[11]),  .oP(p0[4]),  .oG(g0[5]));
    black BLACK06  (.iP0(p[12]),  .iG0(g[12]),  .iP1(p[13]),  .iG1(g[13]),  .oP(p0[5]),  .oG(g0[6]));
    black BLACK07  (.iP0(p[14]),  .iG0(g[14]),  .iP1(p[15]),  .iG1(g[15]),  .oP(p0[6]),  .oG(g0[7]));
    black BLACK08  (.iP0(p[16]),  .iG0(g[16]),  .iP1(p[17]),  .iG1(g[17]),  .oP(p0[7]),  .oG(g0[8]));
    black BLACK09  (.iP0(p[18]),  .iG0(g[18]),  .iP1(p[19]),  .iG1(g[19]),  .oP(p0[8]),  .oG(g0[9]));
    black BLACK0A  (.iP0(p[20]),  .iG0(g[20]),  .iP1(p[21]),  .iG1(g[21]),  .oP(p0[9]),  .oG(g0[10]));
    black BLACK0B  (.iP0(p[22]),  .iG0(g[22]),  .iP1(p[23]),  .iG1(g[23]),  .oP(p0[10]), .oG(g0[11]));
    black BLACK0C  (.iP0(p[24]),  .iG0(g[24]),  .iP1(p[25]),  .iG1(g[25]),  .oP(p0[11]), .oG(g0[12]));
    black BLACK0D  (.iP0(p[26]),  .iG0(g[26]),  .iP1(p[27]),  .iG1(g[27]),  .oP(p0[12]), .oG(g0[13]));
    black BLACK0E  (.iP0(p[28]),  .iG0(g[28]),  .iP1(p[29]),  .iG1(g[29]),  .oP(p0[13]), .oG(g0[14]));
    black BLACK0F  (.iP0(p[30]),  .iG0(g[30]),  .iP1(p[31]),  .iG1(g[31]),  .oP(p0[14]), .oG(g0[15]));
    black BLACK010 (.iP0(p[32]),  .iG0(g[32]),  .iP1(p[33]),  .iG1(g[33]),  .oP(p0[15]), .oG(g0[16]));
    black BLACK011 (.iP0(p[34]),  .iG0(g[34]),  .iP1(p[35]),  .iG1(g[35]),  .oP(p0[16]), .oG(g0[17]));
    black BLACK012 (.iP0(p[36]),  .iG0(g[36]),  .iP1(p[37]),  .iG1(g[37]),  .oP(p0[17]), .oG(g0[18]));
    black BLACK013 (.iP0(p[38]),  .iG0(g[38]),  .iP1(p[39]),  .iG1(g[39]),  .oP(p0[18]), .oG(g0[19]));
    black BLACK014 (.iP0(p[40]),  .iG0(g[40]),  .iP1(p[41]),  .iG1(g[41]),  .oP(p0[19]), .oG(g0[20]));
    black BLACK015 (.iP0(p[42]),  .iG0(g[42]),  .iP1(p[43]),  .iG1(g[43]),  .oP(p0[20]), .oG(g0[21]));
    black BLACK016 (.iP0(p[44]),  .iG0(g[44]),  .iP1(p[45]),  .iG1(g[45]),  .oP(p0[21]), .oG(g0[22]));
    black BLACK017 (.iP0(p[46]),  .iG0(g[46]),  .iP1(p[47]),  .iG1(g[47]),  .oP(p0[22]), .oG(g0[23]));

    // Level 1
    gray  GRAY10   (.iG0(g0[0]),  .iP1(p0[0]),  .iG1(g0[1]),  .oG(g1[0]));
    black BLACK10  (.iP0(p0[1]),  .iG0(g0[2]),  .iP1(p0[2]),  .iG1(g0[3]),  .oP(p1[0]),  .oG(g1[1]));
    black BLACK11  (.iP0(p0[3]),  .iG0(g0[4]),  .iP1(p0[4]),  .iG1(g0[5]),  .oP(p1[1]),  .oG(g1[2]));
    black BLACK12  (.iP0(p0[5]),  .iG0(g0[6]),  .iP1(p0[6]),  .iG1(g0[7]),  .oP(p1[2]),  .oG(g1[3]));
    black BLACK13  (.iP0(p0[7]),  .iG0(g0[8]),  .iP1(p0[8]),  .iG1(g0[9]),  .oP(p1[3]),  .oG(g1[4]));
    black BLACK14  (.iP0(p0[9]),  .iG0(g0[10]), .iP1(p0[10]), .iG1(g0[11]), .oP(p1[4]),  .oG(g1[5]));
    black BLACK15  (.iP0(p0[11]), .iG0(g0[12]), .iP1(p0[12]), .iG1(g0[13]), .oP(p1[5]),  .oG(g1[6]));
    black BLACK16  (.iP0(p0[13]), .iG0(g0[14]), .iP1(p0[14]), .iG1(g0[15]), .oP(p1[6]),  .oG(g1[7]));
    black BLACK17  (.iP0(p0[15]), .iG0(g0[16]), .iP1(p0[16]), .iG1(g0[17]), .oP(p1[7]),  .oG(g1[8]));
    black BLACK18  (.iP0(p0[17]), .iG0(g0[18]), .iP1(p0[18]), .iG1(g0[19]), .oP(p1[8]),  .oG(g1[9]));
    black BLACK19  (.iP0(p0[19]), .iG0(g0[20]), .iP1(p0[20]), .iG1(g0[21]), .oP(p1[9]),  .oG(g1[10]));
    black BLACK1A  (.iP0(p0[21]), .iG0(g0[22]), .iP1(p0[22]), .iG1(g0[23]), .oP(p1[10]), .oG(g1[11]));

    // Level 2
    gray  GRAY20   (.iG0(g1[0]),  .iP1(p1[0]),  .iG1(g1[1]),  .oG(g2[0]));
    black BLACK20  (.iP0(p1[1]),  .iG0(g1[2]),  .iP1(p1[2]),  .iG1(g1[3]),  .oP(p2[0]),  .oG(g2[1]));
    black BLACK21  (.iP0(p1[3]),  .iG0(g1[4]),  .iP1(p1[4]),  .iG1(g1[5]),  .oP(p2[1]),  .oG(g2[2]));
    black BLACK22  (.iP0(p1[5]),  .iG0(g1[6]),  .iP1(p1[6]),  .iG1(g1[7]),  .oP(p2[2]),  .oG(g2[3]));
    black BLACK23  (.iP0(p1[7]),  .iG0(g1[8]),  .iP1(p1[8]),  .iG1(g1[9]),  .oP(p2[3]),  .oG(g2[4]));
    black BLACK24  (.iP0(p1[9]),  .iG0(g1[10]), .iP1(p1[10]), .iG1(g1[11]), .oP(p2[4]),  .oG(g2[5]));

    // Level 3
    gray  GRAY30   (.iG0(g2[0]),  .iP1(p2[0]),  .iG1(g2[1]),  .oG(g3[0]));
    black BLACK30  (.iP0(p2[1]),  .iG0(g2[2]),  .iP1(p2[2]),  .iG1(g2[3]),  .oP(p3[0]),  .oG(g3[1]));
    black BLACK31  (.iP0(p2[3]),  .iG0(g2[4]),  .iP1(p2[4]),  .iG1(g2[5]),  .oP(p3[1]),  .oG(g3[2]));

    // Level 4
    gray  GRAY40   (.iG0(g3[0]),  .iP1(p3[0]),  .iG1(g3[1]),  .oG(g4));

    //Level 5
    gray  GRAY50   (.iG0(g3[0]),  .iP1(p2[1]),  .iG1(g2[2]),  .oG(g5[0]));
    gray  GRAY51   (.iG0(g4),     .iP1(p2[3]),  .iG1(g2[4]),  .oG(g5[1]));
    gray  GRAY52   (.iG0(g4),     .iP1(p3[1]),  .iG1(g3[2]),  .oG(g5[2]));

    // Level 6
    gray  GRAY60   (.iG0(g2[0]),  .iP1(p1[1]),  .iG1(g1[2]),  .oG(g6[0]));
    gray  GRAY61   (.iG0(g3[0]),  .iP1(p1[3]),  .iG1(g1[4]),  .oG(g6[1]));
    gray  GRAY62   (.iG0(g5[0]),  .iP1(p1[5]),  .iG1(g1[6]),  .oG(g6[2]));
    gray  GRAY63   (.iG0(g4),     .iP1(p1[7]),  .iG1(g1[8]),  .oG(g6[3]));
    gray  GRAY64   (.iG0(g5[1]),  .iP1(p1[9]),  .iG1(g1[10]), .oG(g6[4]));

    // Level 7
    gray  GRAY70   (.iG0(g1[0]),  .iP1(p0[1]),  .iG1(g0[2]),  .oG(g7[0]));
    gray  GRAY71   (.iG0(g2[0]),  .iP1(p0[3]),  .iG1(g0[4]),  .oG(g7[1]));
    gray  GRAY72   (.iG0(g6[0]),  .iP1(p0[5]),  .iG1(g0[6]),  .oG(g7[2]));
    gray  GRAY73   (.iG0(g3[0]),  .iP1(p0[7]),  .iG1(g0[8]),  .oG(g7[3]));
    gray  GRAY74   (.iG0(g6[1]),  .iP1(p0[9]),  .iG1(g0[10]), .oG(g7[4]));
    gray  GRAY75   (.iG0(g5[0]),  .iP1(p0[11]), .iG1(g0[12]), .oG(g7[5]));
    gray  GRAY76   (.iG0(g6[2]),  .iP1(p0[13]), .iG1(g0[14]), .oG(g7[6]));
    gray  GRAY77   (.iG0(g4),     .iP1(p0[15]), .iG1(g0[16]), .oG(g7[7]));
    gray  GRAY78   (.iG0(g6[3]),  .iP1(p0[17]), .iG1(g0[18]), .oG(g7[8]));
    gray  GRAY79   (.iG0(g5[1]),  .iP1(p0[19]), .iG1(g0[20]), .oG(g7[9]));
    gray  GRAY7A   (.iG0(g6[4]),  .iP1(p0[21]), .iG1(g0[22]), .oG(g7[10]));

    // Level 8
    gray  GRAY80   (.iG0(g0[0]),  .iP1(p[2]),   .iG1(g[2]),   .oG(g8[0]));
    gray  GRAY81   (.iG0(g1[0]),  .iP1(p[4]),   .iG1(g[4]),   .oG(g8[1]));
    gray  GRAY82   (.iG0(g7[0]),  .iP1(p[6]),   .iG1(g[6]),   .oG(g8[2]));
    gray  GRAY83   (.iG0(g2[0]),  .iP1(p[8]),   .iG1(g[8]),   .oG(g8[3]));
    gray  GRAY84   (.iG0(g7[1]),  .iP1(p[10]),  .iG1(g[10]),  .oG(g8[4]));
    gray  GRAY85   (.iG0(g6[0]),  .iP1(p[12]),  .iG1(g[12]),  .oG(g8[5]));
    gray  GRAY86   (.iG0(g7[2]),  .iP1(p[14]),  .iG1(g[14]),  .oG(g8[6]));
    gray  GRAY87   (.iG0(g3[0]),  .iP1(p[16]),  .iG1(g[16]),  .oG(g8[7]));
    gray  GRAY88   (.iG0(g7[3]),  .iP1(p[18]),  .iG1(g[18]),  .oG(g8[8]));
    gray  GRAY89   (.iG0(g6[1]),  .iP1(p[20]),  .iG1(g[20]),  .oG(g8[9]));
    gray  GRAY8A   (.iG0(g7[4]),  .iP1(p[22]),  .iG1(g[22]),  .oG(g8[10]));
    gray  GRAY8B   (.iG0(g5[0]),  .iP1(p[24]),  .iG1(g[24]),  .oG(g8[11]));
    gray  GRAY8C   (.iG0(g7[5]),  .iP1(p[26]),  .iG1(g[26]),  .oG(g8[12]));
    gray  GRAY8D   (.iG0(g6[2]),  .iP1(p[28]),  .iG1(g[28]),  .oG(g8[13]));
    gray  GRAY8E   (.iG0(g7[6]),  .iP1(p[30]),  .iG1(g[30]),  .oG(g8[14]));
    gray  GRAY8F   (.iG0(g4),     .iP1(p[32]),  .iG1(g[32]),  .oG(g8[15]));
    gray  GRAY810  (.iG0(g7[7]),  .iP1(p[34]),  .iG1(g[34]),  .oG(g8[16]));
    gray  GRAY811  (.iG0(g6[3]),  .iP1(p[36]),  .iG1(g[36]),  .oG(g8[17]));
    gray  GRAY812  (.iG0(g7[8]),  .iP1(p[38]),  .iG1(g[38]),  .oG(g8[18]));
    gray  GRAY813  (.iG0(g5[1]),  .iP1(p[40]),  .iG1(g[40]),  .oG(g8[19]));
    gray  GRAY814  (.iG0(g7[9]),  .iP1(p[42]),  .iG1(g[42]),  .oG(g8[20]));
    gray  GRAY815  (.iG0(g6[4]),  .iP1(p[44]),  .iG1(g[44]),  .oG(g8[21]));
    gray  GRAY816  (.iG0(g7[10]), .iP1(p[46]),  .iG1(g[46]),  .oG(g8[22]));

    // Postprocessing module: Generate sum and carry-out
    postproc #(.BW(BW))
    POSTPROC  (.iP(p), .iCIN({postproc_cin, iCIN}), .oSUM(oRESULT), .oCOUT(oCOUT));

    assign  postproc_cin    = {g5[2], g8[22], g7[10], g8[21], g6[4], g8[20],
                               g7[9], g8[19], g5[1],  g8[18], g7[8], g8[17],
                               g6[3], g8[16], g7[7],  g8[15], g4,    g8[14],
                               g7[6], g8[13], g6[2],  g8[12], g7[5], g8[11],
                               g5[0], g8[10], g7[4],  g8[9],  g6[1], g8[8],
                               g7[3], g8[7],  g3[0],  g8[6],  g7[2], g8[5],
                               g6[0], g8[4],  g7[1],  g8[3],  g2[0], g8[2],
                               g7[0], g8[1],  g1[0],  g8[0],  g0[0], g[0]};

    assign  oBORROW         = ~oCOUT&iCIN;

endmodule