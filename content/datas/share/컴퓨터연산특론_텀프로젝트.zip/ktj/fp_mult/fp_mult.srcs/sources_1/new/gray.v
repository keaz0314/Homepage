`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/05/26 22:29:20
// Design Name: 
// Module Name: gray
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module gray(
    input   wire    iG0,        // Previous GC
    input   wire    iP1, iG1,   // Current PC and GC
    output  wire    oG);        // Generated GC

    assign  oG  = iG1|(iP1&iG0);

endmodule