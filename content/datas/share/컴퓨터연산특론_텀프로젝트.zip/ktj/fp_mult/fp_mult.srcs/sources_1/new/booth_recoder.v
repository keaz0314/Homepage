module booth_recoder(
    input   wire    iX0, iX1, iX2,      // 3 bits of multiplier
    output  wire    oSIGN, oSIGNn,      // Sign of recoded bit
    output  wire    oMAGN0, oMAGN1);    // Magnitude of recoded bit (1x, 2x)

    wire            zero;

    assign  zero    =  &{iX0, iX1, iX2}|
                      ~|{iX0, iX1, iX2};

    assign  oSIGN   = zero?1'b0:iX2;
    assign  oSIGNn  = ~oSIGN;
    assign  oMAGN0  = iX0^iX1;
    assign  oMAGN1  = (iX1^iX2)&(~oMAGN0);

endmodule