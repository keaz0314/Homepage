module preproc #(               // GC and PC generation
    parameter                   BW = 16)(
    input   wire    [BW-1:0]    iX, iY, // Operand 1, 2
    input   wire                iCIN,   // Carry-in
    output  wire    [BW-1:0]    oP,     // Propagetd carry
    output  wire    [BW-1:0]    oG);    // Generated carry

    assign  oP          = iX^iY;
    assign  oG[0]       = (iX[0]&iY[0])|(oP[0]&iCIN);
    assign  oG[BW-1:1]  = iX[BW-1:1]&iY[BW-1:1];

endmodule