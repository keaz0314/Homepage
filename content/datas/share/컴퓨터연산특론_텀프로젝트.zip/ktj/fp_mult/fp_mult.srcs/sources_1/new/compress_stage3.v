module compress_stage3 #(
    parameter                       PS_BW   = 48)(
    input   wire                    iCLK,
    input   wire                    iRESETn,
    input   wire    [4*PS_BW-1:0]   iOP_SET,
    output  wire    [PS_BW-1:0]     oS, oC);

    reg             [PS_BW-1:0]     r_s, r_c;

    wire            [PS_BW-1:0]     s, c;

    wire            [PS_BW-1:0]     x, y, w, z;

    assign  x   = iOP_SET[3*PS_BW+:PS_BW];
    assign  y   = iOP_SET[2*PS_BW+:PS_BW];
    assign  w   = iOP_SET[1*PS_BW+:PS_BW];
    assign  z   = iOP_SET[0*PS_BW+:PS_BW];

    compressor42 #(
        .PS_BW      (PS_BW))
    COMPRESSOR0   (
        .iX         (x),
        .iY         (y),
        .iW         (w),
        .iZ         (z),
        .iCIN       (1'b0),
        .oS         (s),
        .oC         (c),
        .oCOUT      ());

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            r_s <= {PS_BW{1'b0}};
            r_c <= {PS_BW{1'b0}};
        end
        else begin
            r_s <= s;
            r_c <= c;
        end
    end

    assign  oS  = r_s;
    assign  oC  = r_c;

endmodule