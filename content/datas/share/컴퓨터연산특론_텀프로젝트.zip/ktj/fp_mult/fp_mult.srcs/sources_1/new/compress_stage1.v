module compress_stage1 #(
    parameter                       PS_BW   = 48)(
    input   wire                    iCLK,
    input   wire                    iRESETn,
    input   wire    [4*PS_BW-1:0]   iOP_SET0,
    input   wire    [4*PS_BW-1:0]   iOP_SET1,
    input   wire    [4*PS_BW-1:0]   iOP_SET2,
    input   wire    [4*PS_BW-1:0]   iOP_SET3,
    output  wire    [PS_BW-1:0]     oS0, oC0,
    output  wire    [PS_BW-1:0]     oS1, oC1,
    output  wire    [PS_BW-1:0]     oS2, oC2);

    reg             [PS_BW-1:0]     r_s0, r_c0;
    reg             [PS_BW-1:0]     r_s1, r_c1;
    reg             [PS_BW-1:0]     r_s2, r_c2;

    wire            [PS_BW-1:0]     s0, c0;
    wire            [PS_BW-1:0]     s1, c1;
    wire            [PS_BW-1:0]     s2, c2;

    wire            [PS_BW-1:0]     x0, y0, w0, z0;
    wire            [PS_BW-1:0]     x1, y1, w1, z1;
    wire            [PS_BW-1:0]     x2, y2, w2, z2;

    assign  x0  = iOP_SET0[3*PS_BW+:PS_BW];
    assign  y0  = iOP_SET0[2*PS_BW+:PS_BW];
    assign  w0  = iOP_SET0[1*PS_BW+:PS_BW];
    assign  z0  = iOP_SET0[0*PS_BW+:PS_BW];

    assign  x1  = iOP_SET1[3*PS_BW+:PS_BW];
    assign  y1  = iOP_SET1[2*PS_BW+:PS_BW];
    assign  w1  = iOP_SET1[1*PS_BW+:PS_BW];
    assign  z1  = iOP_SET1[0*PS_BW+:PS_BW];

    assign  x2  = iOP_SET2[3*PS_BW+:PS_BW];
    assign  y2  = iOP_SET2[2*PS_BW+:PS_BW];
    assign  w2  = iOP_SET2[1*PS_BW+:PS_BW];
    assign  z2  = iOP_SET2[0*PS_BW+:PS_BW];

    compressor42 #(
        .PS_BW      (PS_BW))
    COMPRESSOR0   (
        .iX         (x0),
        .iY         (y0),
        .iW         (w0),
        .iZ         (z0),
        .iCIN       (1'b0),
        .oS         (s0),
        .oC         (c0),
        .oCOUT      ());

    compressor42 #(
        .PS_BW      (PS_BW))
    COMPRESSOR1   (
        .iX         (x1),
        .iY         (y1),
        .iW         (w1),
        .iZ         (z1),
        .iCIN       (1'b0),
        .oS         (s1),
        .oC         (c1),
        .oCOUT      ());

    compressor42 #(
        .PS_BW      (PS_BW))
    COMPRESSOR2   (
        .iX         (x2),
        .iY         (y2),
        .iW         (w2),
        .iZ         (z2),
        .iCIN       (1'b0),
        .oS         (s2),
        .oC         (c2),
        .oCOUT      ());

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            r_s0    <= {PS_BW{1'b0}};
            r_c0    <= {PS_BW{1'b0}};
            r_s1    <= {PS_BW{1'b0}};
            r_c1    <= {PS_BW{1'b0}};
            r_s2    <= {PS_BW{1'b0}};
            r_c2    <= {PS_BW{1'b0}};
        end
        else begin
            r_s0    <= s0;
            r_c0    <= c0;
            r_s1    <= s1;
            r_c1    <= c1;
            r_s2    <= s2;
            r_c2    <= c2;
        end
    end

    assign  oS0 = r_s0;
    assign  oC0 = r_c0;
    assign  oS1 = r_s1;
    assign  oC1 = r_c1;
    assign  oS2 = r_s2;
    assign  oC2 = r_c2;

endmodule