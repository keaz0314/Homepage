module booth_pp_gen #(
    parameter                   BW      = 24,
                                PP_BW   = 25)(
    input   wire    [BW-1:0]    iA,
    input   wire                iMAGN0, iMAGN1,
    input   wire                iSIGN,
    output  wire    [PP_BW-1:0] oPP);

    wire            [PP_BW-1:0] pp;

    // assign  pp  = iMAGN0?{1'b0, iA}:{iA, 1'b0};

    onehot_mux ONEHOT_MUX_1ST (.iA(iA[0]), .iB(1'b0), .iSEL0(iMAGN0), .iSEL1(iMAGN1), .oOUT(pp[0]));
    genvar i;
    generate
        for(i=0; i<BW-1; i=i+1) begin: ONEHOT_MUX
            onehot_mux ONEHOT_MUX (.iA(iA[i+1]), .iB(iA[i]), .iSEL0(iMAGN0), .iSEL1(iMAGN1), .oOUT(pp[i+1]));
        end
    endgenerate
    onehot_mux ONEHOT_MUX_LAST (.iA(1'b0), .iB(iA[BW-1]), .iSEL0(iMAGN0), .iSEL1(iMAGN1), .oOUT(pp[PP_BW-1]));

    assign  oPP = pp^{PP_BW{iSIGN}};    // If sign = 1, then one's complement

endmodule