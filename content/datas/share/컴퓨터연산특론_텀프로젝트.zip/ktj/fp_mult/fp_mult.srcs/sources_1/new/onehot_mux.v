module onehot_mux(
    input   wire    iA, iB,
    input   wire    iSEL0, iSEL1,
    output  wire    oOUT);

    assign  oOUT    = (iA&iSEL0)|(iB&iSEL1);    // One-hot encoding

endmodule