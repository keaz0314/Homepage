module black(
    input   wire    iP0, iG0,   // Previous PC and GC
    input   wire    iP1, iG1,   // Current PC and GC
    output  wire    oP, oG);    // Generated PC and GC

    assign  oP  = iP1&iP0;
    assign  oG  = iG1|(iP1&iG0);

endmodule