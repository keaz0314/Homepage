module compressor(
    input   wire    iX,
    input   wire    iY,
    input   wire    iW,
    input   wire    iZ,
    input   wire    iCIN,   // Pre-weight
    output  wire    oS,     // Output
    output  wire    oC,     // Next weight
    output  wire    oCOUT); // Otuput

    assign  xor0    = iX^iY;
    assign  xor1    = iW^iZ;
    assign  xor2    = xor0^xor1;
    assign  oS      = xor2^iCIN;
    mux_2by1 MUX0 (.iA(iX), .iB(iW),   .iSEL(xor0), .oOUT(oCOUT));
    mux_2by1 MUX1 (.iA(iZ), .iB(iCIN), .iSEL(xor2), .oOUT(oC));

endmodule