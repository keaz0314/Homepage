module mux_2by1(
    input   wire    iA,
    input   wire    iB,
    input   wire    iSEL,
    output  wire    oOUT);

    assign  oOUT    = (iA&(~iSEL))|(iB&iSEL);

endmodule