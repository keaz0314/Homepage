module rounding #(
    parameter                   M_BW    = 23,
                                S_BW    = 24,
                                ES_BW   = 9,
                                PS_BW   = 48)(
    input   wire                iCLK,
    input   wire                iRESETn,
    input   wire    [ES_BW-1:0] iEXP,
    input   wire    [PS_BW-1:0] iPRODUCT,
    output  wire                oINEXACT,
    output  wire    [ES_BW-1:0] oEXP,
    output  wire    [M_BW-1:0]  oFRACTION);

    reg                         r_inexact;
    reg             [ES_BW-1:0] r_exp;
    reg             [M_BW-1:0]  r_fraction;

    wire            [ES_BW-1:0] exp;
    wire            [M_BW-1:0]  fraction;
    wire            [S_BW-1:0]  significand;
    wire                        overflow;

    wire                        l, r, s;    // LSB, round, sticky
    wire                        incr;       // Round-up flag
    wire                        inexact;

    assign  l       = iPRODUCT[23];
    assign  r       = iPRODUCT[22];
    assign  s       = |iPRODUCT[21:0];

    assign  incr    = r&(s|l);
    assign  inexact = r|s;

    bka_24bit #(
        .BW         (S_BW))
    BKA_24BIT  (
        .iX         (iPRODUCT[46:23]),
        .iY         ({S_BW{1'b0}}),
        .iCIN       (incr),
        .oRESULT    (significand),
        .oCOUT      (overflow));

    // After rounding, check for overflow
    // If detected, perform normalization
    bka_9bit #(
        .BW         (ES_BW))
    BKA_9BIT  (
        .iX         (iEXP),
        .iY         ({ES_BW{1'b0}}),
        .iCIN       (overflow),
        .oRESULT    (exp),
        .oCOUT      ());

    assign  fraction    = overflow?significand[23:1]:significand[22:0];

    always @ (posedge iCLK, negedge iRESETn) begin
        if(!iRESETn) begin
            r_inexact   <= 1'b0;
            r_exp       <= {ES_BW{1'b0}};
            r_fraction  <= {M_BW{1'b0}};
        end
        else begin
            r_inexact   <= inexact;
            r_exp       <= exp;
            r_fraction  <= fraction;
        end
    end

    assign  oINEXACT    = r_inexact;
    assign  oEXP        = r_exp;
    assign  oFRACTION   = r_fraction;

endmodule