module  top #(parameter DATA_BIT    =   8)       
(       
    input   wire    [DATA_BIT-1:0]              ix,
    input   wire    [DATA_BIT-1:0]              ia,

    output  wire    [(2*DATA_BIT)-1:0]          oresult
);

wire    [(DATA_BIT/2)*(DATA_BIT+1)-1:0]     oa;

booth #(.DATA_BIT(DATA_BIT)) booth_u0(
    .ix(ix),
    .ia(ia),
    .oa(oa)
);

rca_set #(.DATA_BIT(DATA_BIT)) rca_set_u0 (
    .ia(oa),
    .op(oresult)
);

endmodule