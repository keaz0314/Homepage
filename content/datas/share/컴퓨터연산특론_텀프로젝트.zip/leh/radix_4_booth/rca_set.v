module  rca_set #(parameter DATA_BIT    =   8)       
(       
    input   wire    [(DATA_BIT/2)*(DATA_BIT+1)-1:0]		ia,
    output  wire	[2*DATA_BIT-1:0]      				op
);

// function 문 : 합성 X, 계산만 해주는 기능
// task 문 : function과 비슷한 기능을 가지고 있음 (공부해보기)
function	integer calc_p_len;
    input integer DATA_BIT;
    integer pcnt;
    begin
		pcnt = (DATA_BIT-8)/2;
		calc_p_len =  ( (DATA_BIT*DATA_BIT) - (DATA_BIT/2 * pcnt) -1 );
    end
endfunction

localparam P_len = calc_p_len(DATA_BIT);

wire	[DATA_BIT:0] osum [(DATA_BIT/2) : 1];	// osum bit extend (+1'b1)
												// DATA_BIT = 8, [8:0] osum [4:1] (osum 4개)

wire	[P_len:0] product; // DATA_BIT = 8이면, P_len = 64가 되어야 함

genvar i;
generate
	for(i=0; i<=(DATA_BIT/2); i=i+1) begin
		if(i==0) begin
			assign product[i*(i+DATA_BIT) +: 2*i+(DATA_BIT+1)] = {DATA_BIT{1'b0}};
		end
		else if(i==1) begin
			assign product[i*(i+DATA_BIT) +: 2*i+(DATA_BIT+1)] = {osum[i][DATA_BIT], osum[i][DATA_BIT], osum[i]};
		end		
		else if(i < (DATA_BIT/2)) begin
			assign product[i*(i+DATA_BIT) +: 2*i+(DATA_BIT+1)] = {osum[i][DATA_BIT], osum[i][DATA_BIT], osum[i], product[ (i*i)+(6*i)-(7*DATA_BIT>>3) +: 2*i-2]};
		end
		else begin
			assign product[i*(i+DATA_BIT) +: 2*i+(DATA_BIT)] = {osum[i][DATA_BIT], osum[i], product[ (i*i)+(6*i)-(7*DATA_BIT>>3) +: 2*i-2]};
		end
	end
    for(i=1; i<=(DATA_BIT/2); i=i+1) begin : RIPPLE_ADDER_GEN
		ripple_carry_adder #(.DATA_BIT(DATA_BIT)) u_ripple_carry_adder (
			.ia(ia[(i-1)*(DATA_BIT+1) +: DATA_BIT+1]),
			.ip(product[(i-1)*(i+DATA_BIT+1) +: DATA_BIT+1]),
			.osum(osum[i])
		);
	end
endgenerate

assign op = product[(3*DATA_BIT*DATA_BIT)>>2 +: 2*DATA_BIT];

endmodule