module  ripple_carry_adder  #(parameter DATA_BIT    =   8)       
(       
    input   wire    [DATA_BIT:0]		ia,
    input   wire    [DATA_BIT:0]        ip,         //  상위 4bit
    
    output  wire    [DATA_BIT:0]      osum
);

    wire [DATA_BIT:1] c;

    genvar i;
    generate
        for (i=0; i<=DATA_BIT; i=i+1) begin
            if(i==0)
                fa u_fa (.ix(ia[i]), .iy(ip[i]), .icarry(1'b0),	.osum(osum[i]),	.ocarry(c[i+1]));
            else if(i!=DATA_BIT)
                fa u_fa (.ix(ia[i]), .iy(ip[i]), .icarry(c[i]),	.osum(osum[i]),	.ocarry(c[i+1]));
            else
                fa u_fa (.ix(ia[i]), .iy(ip[i]), .icarry(c[i]),	.osum(osum[i]),	.ocarry());
        end
    endgenerate

endmodule