`timescale 1ns/1ps
 
module      tb_top();

    localparam          CLK_HPER    =   5;

    reg                 iclk;
    reg                 inrst;

    reg     [7:0]       ix;
    reg     [7:0]       ia;

    wire    [15:0]       oresult;


    top #(.DATA_BIT(8)) top_0 (
        .ix(ix),
        .ia(ia),

        .oresult(oresult)
    );

    always begin
        #(CLK_HPER);
        iclk    <=      ~iclk;
    end

    initial begin
        iclk    <=      1'b0;
        inrst   <=      1'b0;
        
        ix      <=      8'd0;
        ia      <=      8'd0;

        #(CLK_HPER);
        inrst   <=      1'b1;

        #(2*CLK_HPER);
        ix      <=      -8'd105;
        ia      <=      8'd127;
        
        #(6*CLK_HPER);
        ix      <=      8'd105;
        ia      <=      -8'd127;
        
        #(6*CLK_HPER);
        ix      <=      -8'd100;
        ia      <=      -8'd100;

        #(6*CLK_HPER);
        ix      <=      8'd11;
        ia      <=      8'd20;
        
        #(6*CLK_HPER);
        $finish();
    end

endmodule