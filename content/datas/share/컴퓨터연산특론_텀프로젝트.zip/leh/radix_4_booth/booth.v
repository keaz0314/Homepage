module booth #(parameter DATA_BIT    =   8)       
(       
    input   wire    signed  [DATA_BIT-1:0]                  ix,
    input   wire    signed  [DATA_BIT-1:0]                  ia,

    output  reg     signed  [(DATA_BIT/2)*(DATA_BIT+1)-1:0]     oa
);
    wire    signed  [DATA_BIT:0]    extension_x;
    wire    signed  [DATA_BIT:0]    extension_a;    // 1bit extend
    wire    signed  [DATA_BIT:0]    ext_sub_a;

    assign  extension_a     = {ia[DATA_BIT-1], ia};
    assign  ext_sub_a       = ~extension_a  +  1'b1;
    
    assign  extension_x =   {ix, 1'b0};
    
    genvar  i;
    generate
        for(i=0;i<DATA_BIT;i=i+2) begin
            always @(*) begin
                case ({extension_x[i+2],extension_x[i+1],extension_x[i]})
                    3'b000 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = {DATA_BIT{1'b0}};
                    3'b001 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = extension_a;                                        // +A
                    3'b010 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = extension_a;                                        // +A
                    3'b011 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = {{extension_a[DATA_BIT]},   extension_a,    1'b0};  // +2A

                    3'b100 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = {{ext_sub_a[DATA_BIT]},     ext_sub_a,      1'b0};  // -2A
                    3'b101 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = ext_sub_a;                                          // -A
                    3'b110 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = ext_sub_a;                                          // -A
                    3'b111 : oa[ ((DATA_BIT+1)*i)>>1 +: DATA_BIT+1 ]  = {DATA_BIT{1'b0}};
                endcase
            end
        end
    endgenerate
endmodule