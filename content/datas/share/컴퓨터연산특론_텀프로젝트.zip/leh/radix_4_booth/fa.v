module  fa
(
    input   wire            ix,
    input   wire            iy,
    input   wire            icarry,

    output                   osum,
    output                   ocarry
);

    assign                  osum    =   ix ^ iy ^ icarry;
    assign                  ocarry  =   (ix & iy) | (ix & icarry) | (iy & icarry);

endmodule