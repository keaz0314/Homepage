// ===================================================================================
// Module:    fp16_multiplier 
// Author:    Taehyeon An
// ===================================================================================
module fp16_multiplier (
    input  wire [15:0] a,
    input  wire [15:0] b,
    output reg  [15:0] result 
);

    // --- 입력 분해 및 FP16 구조 정의 ---
    wire sign_a = a[15];
    wire [4:0] exp_a = a[14:10];
    wire [9:0] mant_a = a[9:0];

    wire sign_b = b[15];
    wire [4:0] exp_b = b[14:10];
    wire [9:0] mant_b = b[9:0];

    // --- 특수값 감지 ---
    wire a_is_zero     = (exp_a == 5'b0) && (mant_a == 10'b0);
    wire b_is_zero     = (exp_b == 5'b0) && (mant_b == 10'b0);
    wire a_is_inf      = (exp_a == 5'b11111) && (mant_a == 10'b0);
    wire b_is_inf      = (exp_b == 5'b11111) && (mant_b == 10'b0);
    wire a_is_nan      = (exp_a == 5'b11111) && (mant_a != 10'b0);
    wire b_is_nan      = (exp_b == 5'b11111) && (mant_b != 10'b0);
    wire a_is_denormal = (exp_a == 5'b0) && (mant_a != 10'b0);
    wire b_is_denormal = (exp_b == 5'b0) && (mant_b != 10'b0);
    
    // --- 중간 결과 저장을 위한 변수 ---
    reg result_sign;
    reg signed [7:0] result_exp;
    reg [21:0] mant_prod;
    reg [21:0] mant_norm;
    reg [4:0] final_exp;
    reg [9:0] final_mant;
    reg [9:0] mant_to_round;
    reg guard_bit, round_bit, sticky_bit, lsb, round_up;

    // Barrel Shifter 구현용
    reg [4:0] shift_amount; // 왼쪽으로 시프트할 양 (최대 20칸)

    // --- 곱셈 연산 수행 ---
    always @* begin
        // --- 특수값 우선 처리 ---
        if (a_is_nan || b_is_nan) begin
            result = 16'b0_11111_1000000000;
        end else if ((a_is_inf && b_is_zero) || (a_is_zero && b_is_inf)) begin
            result = 16'b0_11111_1000000000;
        end else if (a_is_inf || b_is_inf) begin
            result = {(sign_a ^ sign_b), 5'b11111, 10'b0};
        end else if (a_is_zero || b_is_zero) begin
            result = {(sign_a ^ sign_b), 5'b0, 10'b0};
        
        // --- 정규수 및 비정규수 곱셈 처리 ---
        end else begin
            result_sign = sign_a ^ sign_b;
            result_exp = (a_is_denormal ? (1 - 15) : (exp_a - 15)) + 
                         (b_is_denormal ? (1 - 15) : (exp_b - 15));
            mant_prod = { !a_is_denormal, mant_a } * { !b_is_denormal, mant_b };

            // ================== Barrel Shifter 적용 정규화 로직 ==================
            // 정규화: 곱셈 결과를 '1.xxxx...' 형태로 표준화
            if (mant_prod == 0) begin
                result_exp = -127;
                mant_norm = 0;
            end else if (mant_prod[21]) begin // 오른쪽 시프트: 결과가 2.0 이상인 경우
                mant_norm = mant_prod >> 1;
                result_exp = result_exp + 1;
            end else begin // 그 외 모든 경우: 정규화 불필요 또는 왼쪽 시프트
                // --- Priority Encoder ---
                // casex를 사용하여 몇 칸을 왼쪽으로 시프트할지(shift_amount) 한 번에 계산
                // 즉, 최상위 '1'의 위치를 찾는 작업을 수행
                casex(mant_prod[20:0])
                    21'b1????????????????????: shift_amount = 0;  // 20번째 비트가 1: 시프트 불필요
                    21'b01???????????????????: shift_amount = 1;
                    21'b001??????????????????: shift_amount = 2;
                    21'b0001?????????????????: shift_amount = 3;
                    21'b00001????????????????: shift_amount = 4;
                    21'b000001???????????????: shift_amount = 5;
                    21'b0000001??????????????: shift_amount = 6;
                    21'b00000001?????????????: shift_amount = 7;
                    21'b000000001????????????: shift_amount = 8;
                    21'b0000000001???????????: shift_amount = 9;
                    21'b00000000001??????????: shift_amount = 10;
                    21'b000000000001?????????: shift_amount = 11;
                    21'b0000000000001????????: shift_amount = 12;
                    21'b00000000000001???????: shift_amount = 13;
                    21'b000000000000001??????: shift_amount = 14;
                    21'b0000000000000001?????: shift_amount = 15;
                    21'b00000000000000001????: shift_amount = 16;
                    21'b000000000000000001???: shift_amount = 17;
                    21'b0000000000000000001??: shift_amount = 18;
                    21'b00000000000000000001?: shift_amount = 19;
                    21'b0000000000000000000001: shift_amount = 20;
                    default: shift_amount = 0; // 이론상 도달 불가
                endcase
                
                // --- Barrel Shifter ---
                // 계산된 shift_amount만큼 가수를 한 번에 왼쪽으로 시프트
                mant_norm = mant_prod << shift_amount;
                
                // 시프트한 만큼 지수를 보정
                result_exp = result_exp - shift_amount;
            end
            // ================================================================
            
            // 최종 지수 계산 및 1차 경계값 검사
            final_exp = result_exp + 15;
            if (result_exp > 15) begin
                result = {result_sign, 5'b11111, 10'b0};
            end else if (result_exp < -14) begin
                result = {result_sign, 5'b0, 10'b0};
            end else begin
                // 라운딩
                mant_to_round = mant_norm[19:10];
                guard_bit     = mant_norm[9];
                round_bit     = mant_norm[8];
                sticky_bit    = |(mant_norm[7:0]);
                lsb           = mant_to_round[0];
                round_up      = guard_bit && (round_bit || sticky_bit || lsb);
                {final_exp, final_mant} = {final_exp, mant_to_round} + round_up;
                
                // 2차 경계값 검사 (라운딩으로 인한 오버플로우)
                if (final_exp >= 31) begin
                    result = {result_sign, 5'b11111, 10'b0};
                end else begin
                    // 최종 결과
                    result = {result_sign, final_exp, final_mant};
                end
            end
        end
    end
endmodule
